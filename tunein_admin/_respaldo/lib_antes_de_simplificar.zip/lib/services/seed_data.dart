import 'package:cloud_firestore/cloud_firestore.dart';

import 'current_user.dart';

/// Carga emisoras, posts y audio moments de DEMO en Firestore.
/// Se ejecuta desde Perfil → "Cargar datos demo" (una sola vez).
///
/// Las imágenes vienen de picsum.photos y los audios de SoundHelix
/// (MP3 libres) para simular la transmisión. Las emisoras demo quedan a
/// nombre del usuario que las carga, así ese usuario puede editarlas.
class SeedData {
  SeedData._();

  static String _img(String seed) => 'https://picsum.photos/seed/$seed/600/600';
  static String _mp3(int n) =>
      'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-$n.mp3';

  static final _stations = <Map<String, dynamic>>[
    {
      'id': 'radio-cordillera',
      'name': 'Radio Cordillera',
      'genre': 'Música',
      'category': 'radio',
      'location': 'Santiago, Chile',
      'frequency': '88.5 FM',
      'description': 'Pop, indie y rock chileno las 24 horas.',
      'lat': -33.4489, 'lng': -70.6693, 'audio': 1,
    },
    {
      'id': 'pulso-deportivo',
      'name': 'Pulso Deportivo',
      'genre': 'Deporte',
      'category': 'deporte',
      'location': 'Santiago, Chile',
      'frequency': '95.3 FM',
      'description': 'Fútbol, tenis y todo el deporte nacional en vivo.',
      'lat': -33.4372, 'lng': -70.6050, 'audio': 2,
    },
    {
      'id': 'noticias-andinas',
      'name': 'Noticias Andinas',
      'genre': 'Noticias',
      'category': 'radio',
      'location': 'Valparaíso, Chile',
      'frequency': '101.7 FM',
      'description': 'Informativo regional con boletines cada hora.',
      'lat': -33.0472, 'lng': -71.6127, 'audio': 3,
    },
    {
      'id': 'frecuencia-austral',
      'name': 'Frecuencia Austral',
      'genre': 'Música',
      'category': 'radio',
      'location': 'Punta Arenas, Chile',
      'frequency': '92.1 FM',
      'description': 'La música del fin del mundo.',
      'lat': -53.1638, 'lng': -70.9171, 'audio': 4,
    },
    {
      'id': 'sintonia-norte',
      'name': 'Sintonía Norte',
      'genre': 'Noticias',
      'category': 'radio',
      'location': 'Antofagasta, Chile',
      'frequency': '99.9 FM',
      'description': 'Actualidad y conversación desde el norte.',
      'lat': -23.6509, 'lng': -70.3975, 'audio': 5,
    },
    {
      'id': 'la-desayunadora',
      'name': 'La Desayunadora',
      'genre': 'Humor',
      'category': 'podcast',
      'location': 'Concepción, Chile',
      'frequency': 'Podcast',
      'description': 'Las mañanas más ruidosas del sur. Desayunando con huesitos.',
      'lat': -36.8270, 'lng': -73.0503, 'audio': 6,
    },
    {
      'id': 'ritmo-porteno',
      'name': 'Ritmo Porteño',
      'genre': 'Música',
      'category': 'radio',
      'location': 'Buenos Aires, Argentina',
      'frequency': '104.3 FM',
      'description': 'Tango, rock nacional y cumbia porteña.',
      'lat': -34.6037, 'lng': -58.3816, 'audio': 7,
    },
    {
      'id': 'gol-a-gol',
      'name': 'Gol a Gol',
      'genre': 'Deporte',
      'category': 'deporte',
      'location': 'Rosario, Argentina',
      'frequency': '97.5 FM',
      'description': 'Relatos en vivo y análisis de cada fecha.',
      'lat': -32.9442, 'lng': -60.6505, 'audio': 8,
    },
    {
      'id': 'cafe-diseno',
      'name': 'Café Diseño',
      'genre': 'Diseño',
      'category': 'podcast',
      'location': 'Santiago, Chile',
      'frequency': 'Podcast',
      'description': 'Conversaciones sobre diseño de interacción y producto.',
      'lat': -33.4000, 'lng': -70.5700, 'audio': 9,
    },
    {
      'id': 'onda-patagonia',
      'name': 'Onda Patagonia',
      'genre': 'Música',
      'category': 'radio',
      'location': 'Puerto Montt, Chile',
      'frequency': '90.7 FM',
      'description': 'Folk, acústico y sonidos del sur.',
      'lat': -41.4689, 'lng': -72.9411, 'audio': 10,
    },
    {
      'id': 'radio-altiplano',
      'name': 'Radio Altiplano',
      'genre': 'Noticias',
      'category': 'radio',
      'location': 'La Paz, Bolivia',
      'frequency': '100.1 FM',
      'description': 'Noticias y cultura andina.',
      'lat': -16.4897, 'lng': -68.1193, 'audio': 11,
    },
    {
      'id': 'renaci-mientes',
      'name': 'Renaci-mientes',
      'genre': 'Bienestar',
      'category': 'podcast',
      'location': 'Lima, Perú',
      'frequency': 'Podcast',
      'description': 'Historias de volver a empezar.',
      'lat': -12.0464, 'lng': -77.0428, 'audio': 12,
    },
  ];

  static const _postTitles = [
    ['Detrás de cámaras', 'Así se ve la cabina en un día de transmisión.'],
    ['Día nacional de la radio', 'Gracias por sintonizarnos todos estos años.'],
    ['Nuevo horario', 'Desde el lunes, el matinal parte a las 7:00.'],
  ];

  static const _momentTitles = [
    'Lo mejor de la semana',
    'Entrevista completa',
    'El momento más comentado',
  ];

  static const _sampleComments = [
    ['camila.r', '¡Los escucho todas las mañanas!'],
    ['benja_94', 'Qué buen programa el de hoy.'],
    ['fran.diseña', 'Suban más clips de la entrevista 🙌'],
  ];

  /// Escribe todo en lotes. Devuelve cuántas emisoras se cargaron.
  static Future<int> run() async {
    final fs = FirebaseFirestore.instance;
    final uid = CurrentUser.id;
    final batch = fs.batch();
    var audioN = 13;

    for (final s in _stations) {
      final id = s['id'] as String;
      final ref = fs.collection('stations').doc(id);
      batch.set(ref, {
        'name': s['name'],
        'nameLower': (s['name'] as String).toLowerCase(),
        'genre': s['genre'],
        'category': s['category'],
        'location': s['location'],
        'frequency': s['frequency'],
        'description': s['description'],
        'imageUrl': _img(id),
        'audioUrl': _mp3(s['audio'] as int),
        'lat': s['lat'],
        'lng': s['lng'],
        'ownerUid': uid,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Posts
      for (var i = 0; i < _postTitles.length; i++) {
        final postRef = ref.collection('posts').doc('$id-post-$i');
        final withComments = i == 0;
        batch.set(postRef, {
          'stationId': id,
          'title': _postTitles[i][0],
          'summary': _postTitles[i][1],
          'imageUrl': _img('$id-post-$i'),
          'likeCount': 0,
          'commentCount': withComments ? _sampleComments.length : 0,
          'createdAt': Timestamp.fromDate(
            DateTime.now().subtract(Duration(hours: i * 20 + 1)),
          ),
        });
        if (withComments) {
          for (var c = 0; c < _sampleComments.length; c++) {
            batch.set(postRef.collection('comments').doc('c$c'), {
              'uid': uid,
              'username': _sampleComments[c][0],
              'text': _sampleComments[c][1],
              'createdAt': Timestamp.fromDate(
                DateTime.now().subtract(Duration(minutes: 60 - c * 10)),
              ),
            });
          }
        }
      }

      // Audio moments
      final momentTitles = id == 'la-desayunadora'
          ? [
              'Desayunando con huesitos Cap 1',
              'Desayunando con huesitos Cap 2',
              'Desayunando con huesitos Cap 3',
            ]
          : id == 'renaci-mientes'
              ? ['Renaci-mientes Cap 1', 'Renaci-mientes Cap 2']
              : _momentTitles;
      for (var i = 0; i < momentTitles.length; i++) {
        batch.set(ref.collection('moments').doc('$id-moment-$i'), {
          'stationId': id,
          'title': momentTitles[i],
          'audioUrl': _mp3(audioN),
          'imageUrl': _img('$id-moment-$i'),
          'durationMs': null,
          'likeCount': 0,
          'createdAt': Timestamp.fromDate(
            DateTime.now().subtract(Duration(days: i)),
          ),
        });
        audioN = audioN >= 16 ? 1 : audioN + 1;
      }
    }

    await batch.commit();
    return _stations.length;
  }
}
