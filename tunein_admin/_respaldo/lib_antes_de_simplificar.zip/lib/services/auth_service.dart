import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Autenticación con correo + contraseña (Firebase Auth).
class AuthService {
  AuthService._();

  static final _auth = FirebaseAuth.instance;
  static final _db = FirebaseFirestore.instance;

  static Stream<User?> authChanges() => _auth.authStateChanges();
  static User? get currentUser => _auth.currentUser;
  static String? get uid => _auth.currentUser?.uid;

  static Future<void> signIn(String email, String password) async {
    await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
  }

  /// Crea la cuenta y el documento `users/{uid}`.
  static Future<void> register({
    required String firstName,
    required String lastName,
    required String email,
    required String username,
    required String password,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = cred.user!;
    await user.updateDisplayName(username.trim());
    await _db.collection('users').doc(user.uid).set({
      'firstName': firstName.trim(),
      'lastName': lastName.trim(),
      'username': username.trim(),
      'email': email.trim(),
      'stationId': null,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> sendPasswordReset(String email) =>
      _auth.sendPasswordResetEmail(email: email.trim());

  static Future<void> signOut() => _auth.signOut();

  /// Mensajes en español para los errores más comunes de Firebase Auth.
  static String messageFor(Object e) {
    if (e is FirebaseAuthException) {
      switch (e.code) {
        case 'invalid-email':
          return 'El correo no es válido.';
        case 'user-not-found':
        case 'wrong-password':
        case 'invalid-credential':
          return 'Correo o contraseña incorrectos.';
        case 'email-already-in-use':
          return 'Ya existe una cuenta con ese correo.';
        case 'weak-password':
          return 'La contraseña debe tener al menos 6 caracteres.';
        case 'too-many-requests':
          return 'Demasiados intentos. Espera un momento.';
        case 'network-request-failed':
          return 'Sin conexión. Revisa tu internet.';
        case 'operation-not-allowed':
          return 'Activa "Correo/Contraseña" en Firebase Authentication.';
      }
      return e.message ?? 'Error de autenticación (${e.code}).';
    }
    return 'Algo salió mal. Intenta otra vez.';
  }
}
