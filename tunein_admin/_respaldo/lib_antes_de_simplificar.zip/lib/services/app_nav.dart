import 'package:flutter/foundation.dart';

import '../models/station.dart';

/// Estado de navegación compartido entre pestañas.
/// Ej: "Encontrar en el mapa" desde el reproductor cambia a la pestaña Map
/// y centra la emisora.
class AppNav {
  AppNav._();

  static const home = 0;
  static const library = 1;
  static const map = 2;
  static const search = 3;

  static final tab = ValueNotifier<int>(home);
  static final mapFocus = ValueNotifier<Station?>(null);

  static void showOnMap(Station s) {
    mapFocus.value = s;
    tab.value = map;
  }
}
