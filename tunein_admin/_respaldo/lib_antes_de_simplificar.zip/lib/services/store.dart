import 'dart:async';

import 'package:flutter/foundation.dart';

import '../models/app_user.dart';
import '../models/station.dart';
import 'db.dart';

/// Caché en memoria de los datos que usan varias pantallas a la vez.
/// Se abre al entrar a la app (MainShell) y se cierra al salir.
/// Las pantallas escuchan con ValueListenableBuilder / ListenableBuilder.
class Store {
  Store._();

  static final stations = ValueNotifier<List<Station>?>(null); // null = cargando
  static final favoriteIds = ValueNotifier<Set<String>>(<String>{});
  static final recentIds = ValueNotifier<List<String>>(const []);
  static final likedIds = ValueNotifier<Set<String>>(<String>{});
  static final me = ValueNotifier<AppUser?>(null);
  static final error = ValueNotifier<String?>(null);

  static final List<StreamSubscription<Object?>> _subs = [];

  static void start() {
    stop();
    void onError(Object e) {
      error.value = 'No se pudo leer Firestore: $e';
      debugPrint('Store: $e');
    }

    _subs.addAll([
      Db.stations().listen((v) {
        stations.value = v;
        error.value = null;
      }, onError: onError),
      Db.favoriteIds().listen((v) => favoriteIds.value = v, onError: onError),
      Db.recentIds().listen((v) => recentIds.value = v, onError: onError),
      Db.likedIds().listen((v) => likedIds.value = v, onError: onError),
      Db.me().listen((v) => me.value = v, onError: onError),
    ]);
  }

  static void stop() {
    for (final s in _subs) {
      s.cancel();
    }
    _subs.clear();
    stations.value = null;
    favoriteIds.value = <String>{};
    recentIds.value = const [];
    likedIds.value = <String>{};
    me.value = null;
    error.value = null;
  }

  static Station? stationById(String id) {
    final list = stations.value;
    if (list == null) return null;
    for (final s in list) {
      if (s.id == id) return s;
    }
    return null;
  }

  static List<Station> get favoriteStations => (stations.value ?? const [])
      .where((s) => favoriteIds.value.contains(s.id))
      .toList();

  static List<Station> get recentStations => recentIds.value
      .map(stationById)
      .whereType<Station>()
      .toList();
}
