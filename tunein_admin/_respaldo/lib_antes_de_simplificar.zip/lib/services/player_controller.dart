import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import '../models/social.dart';
import '../models/station.dart';
import 'db.dart';

/// Lo que está sonando ahora: una emisora (radio simulada) o un audio moment.
class NowPlaying {
  const NowPlaying({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.imageUrl,
    required this.audioUrl,
    required this.station,
    this.isMoment = false,
  });

  final String id; // stationId o momentId
  final String title;
  final String subtitle;
  final String imageUrl;
  final String audioUrl;
  final Station station; // emisora dueña del audio
  final bool isMoment;
}

/// Reproductor global (un solo AudioPlayer para toda la app).
/// Uso: `PlayerController.instance.playStation(station, queue: lista)`.
class PlayerController extends ChangeNotifier {
  PlayerController._() {
    _stateSub = _player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.completed &&
          _nowPlaying?.isMoment == false) {
        // La "radio" no termina: al acabar el archivo, vuelve a empezar.
        _player.seek(Duration.zero);
      }
      notifyListeners();
    });
  }

  static final PlayerController instance = PlayerController._();

  final AudioPlayer _player = AudioPlayer();
  late final StreamSubscription<PlayerState> _stateSub;

  NowPlaying? _nowPlaying;
  List<Station> _queue = const [];
  String? _error;
  Timer? _sleepTimer;
  DateTime? _sleepAt;

  NowPlaying? get nowPlaying => _nowPlaying;
  NowPlaying get _current => _nowPlaying!;
  bool get hasMedia => _nowPlaying != null;
  bool get isPlaying => _player.playing;
  bool get isLoading {
    final p = _player.processingState;
    return p == ProcessingState.loading || p == ProcessingState.buffering;
  }

  String? get error => _error;
  DateTime? get sleepAt => _sleepAt;

  Stream<Duration> get positionStream => _player.positionStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Duration get position => _player.position;
  Duration? get duration => _player.duration;

  bool isCurrent(String id) => _nowPlaying?.id == id;

  /// Reproduce una emisora. [queue] define anterior/siguiente.
  Future<void> playStation(Station station, {List<Station>? queue}) async {
    if (queue != null && queue.isNotEmpty) _queue = queue;
    if (isCurrent(station.id)) {
      // Ojo: en just_audio, play() no termina hasta que se pausa.
      if (!isPlaying) unawaited(_player.play());
      return;
    }
    _nowPlaying = NowPlaying(
      id: station.id,
      title: station.name,
      subtitle: station.subtitle,
      imageUrl: station.imageUrl,
      audioUrl: station.audioUrl,
      station: station,
    );
    unawaited(Db.addRecent(station.id).catchError((_) {}));
    await _load();
  }

  /// Reproduce un audio moment (clip) de una emisora.
  Future<void> playMoment(AudioMoment moment, Station station) async {
    if (isCurrent(moment.id)) {
      await toggle();
      return;
    }
    _nowPlaying = NowPlaying(
      id: moment.id,
      title: moment.title,
      subtitle: station.name,
      imageUrl: moment.imageUrl.isNotEmpty ? moment.imageUrl : station.imageUrl,
      audioUrl: moment.audioUrl,
      station: station,
      isMoment: true,
    );
    await _load();
  }

  Future<void> _load() async {
    _error = null;
    notifyListeners();
    try {
      await _player.setUrl(_current.audioUrl);
      unawaited(_player.play());
    } catch (e) {
      _error = 'No se pudo reproducir este audio.';
      debugPrint('PlayerController: $e');
    }
    notifyListeners();
  }

  Future<void> toggle() async {
    if (!hasMedia) return;
    if (isPlaying) {
      await _player.pause();
    } else {
      if (_player.processingState == ProcessingState.completed) {
        await _player.seek(Duration.zero);
      }
      unawaited(_player.play());
    }
    notifyListeners();
  }

  Future<void> pause() => _player.pause();

  Future<void> seek(Duration d) => _player.seek(d);

  int get _queueIndex =>
      _queue.indexWhere((s) => s.id == _nowPlaying?.station.id);

  bool get canSkip => _queue.length > 1;

  Future<void> next() async {
    if (!canSkip) return;
    final i = _queueIndex;
    await playStation(_queue[(i + 1) % _queue.length]);
  }

  Future<void> previous() async {
    if (!canSkip) return;
    // Como en Spotify: si ya pasaron 3 s, vuelve al inicio.
    if (_player.position > const Duration(seconds: 3)) {
      await _player.seek(Duration.zero);
      return;
    }
    final i = _queueIndex;
    await playStation(_queue[(i - 1 + _queue.length) % _queue.length]);
  }

  /// Timer de sueño: pausa después de [d]. null = cancelar.
  void setSleepTimer(Duration? d) {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    _sleepAt = null;
    if (d != null) {
      _sleepAt = DateTime.now().add(d);
      _sleepTimer = Timer(d, () {
        _player.pause();
        _sleepAt = null;
        notifyListeners();
      });
    }
    notifyListeners();
  }

  /// Detiene todo (al cerrar sesión).
  Future<void> stop() async {
    await _player.stop();
    _nowPlaying = null;
    setSleepTimer(null);
  }

  @override
  void dispose() {
    _stateSub.cancel();
    _player.dispose();
    super.dispose();
  }
}
