import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/app_user.dart';
import '../models/social.dart';
import '../models/station.dart';
import 'current_user.dart';

/// Acceso a Firestore. Estructura:
///
/// users/{uid}                         perfil (+ stationId si es emisora)
///   favorites/{stationId}             Librería (emisoras guardadas)
///   recents/{stationId}               Recientes (historial)
///   likes/{itemId}                    Tus Favs (posts y audio moments)
/// stations/{stationId}                emisora
///   posts/{postId}                    publicaciones
///     comments/{commentId}            comentarios
///   moments/{momentId}                audio moments (clips)
class Db {
  Db._();

  static final _fs = FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> get stationsCol =>
      _fs.collection('stations');
  static CollectionReference<Map<String, dynamic>> get usersCol =>
      _fs.collection('users');

  static String get _uid => CurrentUser.id;
  static DocumentReference<Map<String, dynamic>> get _me => usersCol.doc(_uid);

  // ---------------------------------------------------------------- USERS

  static Stream<AppUser?> me() => _me
      .snapshots()
      .map((d) => d.exists ? AppUser.fromDoc(d) : null);

  // -------------------------------------------------------------- STATIONS

  /// Todas las emisoras (la app es chica: se filtran en el cliente).
  static Stream<List<Station>> stations() => stationsCol
      .orderBy('name')
      .snapshots()
      .map((s) => s.docs.map(Station.fromDoc).toList());

  static Stream<Station?> station(String id) => stationsCol
      .doc(id)
      .snapshots()
      .map((d) => d.exists ? Station.fromDoc(d) : null);

  /// Crea la emisora del usuario actual y lo convierte en emisora.
  static Future<String> createStation(Station s, {String? id}) async {
    final ref = stationsCol.doc(id);
    final batch = _fs.batch();
    batch.set(ref, {
      ...s.toMap(),
      'ownerUid': _uid,
      'createdAt': FieldValue.serverTimestamp(),
    });
    batch.set(_me, {'stationId': ref.id}, SetOptions(merge: true));
    await batch.commit();
    return ref.id;
  }

  static Future<void> updateStation(String id, Map<String, dynamic> data) =>
      stationsCol.doc(id).update(data);

  // ------------------------------------------------------------- FAVORITES

  static Stream<Set<String>> favoriteIds() => _me
      .collection('favorites')
      .snapshots()
      .map((s) => s.docs.map((d) => d.id).toSet());

  static Future<void> setFavorite(String stationId, bool value) {
    final ref = _me.collection('favorites').doc(stationId);
    return value
        ? ref.set({'addedAt': FieldValue.serverTimestamp()})
        : ref.delete();
  }

  // --------------------------------------------------------------- RECENTS

  /// IDs de emisoras escuchadas, la más reciente primero.
  static Stream<List<String>> recentIds({int limit = 12}) => _me
      .collection('recents')
      .orderBy('playedAt', descending: true)
      .limit(limit)
      .snapshots()
      .map((s) => s.docs.map((d) => d.id).toList());

  static Future<void> addRecent(String stationId) => _me
      .collection('recents')
      .doc(stationId)
      .set({'playedAt': FieldValue.serverTimestamp()});

  // ------------------------------------------------------------ POSTS / MOMENTS

  static Stream<List<Post>> posts(String stationId) => stationsCol
      .doc(stationId)
      .collection('posts')
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map(Post.fromDoc).toList());

  static Stream<List<AudioMoment>> moments(String stationId) => stationsCol
      .doc(stationId)
      .collection('moments')
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map(AudioMoment.fromDoc).toList());

  static Future<void> addPost({
    required String stationId,
    required String title,
    required String summary,
    required String imageUrl,
  }) =>
      stationsCol.doc(stationId).collection('posts').add({
        'stationId': stationId,
        'title': title,
        'summary': summary,
        'imageUrl': imageUrl,
        'likeCount': 0,
        'commentCount': 0,
        'createdAt': FieldValue.serverTimestamp(),
      });

  static Future<void> addMoment({
    required String stationId,
    required String title,
    required String audioUrl,
    required String imageUrl,
    int? durationMs,
  }) =>
      stationsCol.doc(stationId).collection('moments').add({
        'stationId': stationId,
        'title': title,
        'audioUrl': audioUrl,
        'imageUrl': imageUrl,
        'durationMs': durationMs,
        'likeCount': 0,
        'createdAt': FieldValue.serverTimestamp(),
      });

  static Future<void> deletePost(String stationId, String postId) =>
      stationsCol.doc(stationId).collection('posts').doc(postId).delete();

  static Future<void> deleteMoment(String stationId, String momentId) =>
      stationsCol.doc(stationId).collection('moments').doc(momentId).delete();

  // ----------------------------------------------------------------- LIKES

  /// IDs de todo lo que el usuario likeó (para pintar corazones).
  static Stream<Set<String>> likedIds() => _me
      .collection('likes')
      .snapshots()
      .map((s) => s.docs.map((d) => d.id).toSet());

  /// "Tus Favs" de una emisora.
  static Stream<List<LikedItem>> likesForStation(String stationId) => _me
      .collection('likes')
      .where('stationId', isEqualTo: stationId)
      .snapshots()
      .map((s) => s.docs.map(LikedItem.fromDoc).toList());

  static Future<void> setLike(LikedItem item, bool value) async {
    final likeRef = _me.collection('likes').doc(item.itemId);
    final itemRef = stationsCol
        .doc(item.stationId)
        .collection(item.type == LikeType.post ? 'posts' : 'moments')
        .doc(item.itemId);
    final batch = _fs.batch();
    if (value) {
      batch.set(likeRef, item.toMap());
    } else {
      batch.delete(likeRef);
    }
    batch.update(itemRef, {'likeCount': FieldValue.increment(value ? 1 : -1)});
    try {
      await batch.commit();
    } on FirebaseException catch (e) {
      // Si el post fue borrado, igual quitamos el like del usuario.
      if (e.code == 'not-found' && !value) {
        await likeRef.delete();
      } else {
        rethrow;
      }
    }
  }

  // -------------------------------------------------------------- COMMENTS

  static Stream<List<Comment>> comments(String stationId, String postId) =>
      stationsCol
          .doc(stationId)
          .collection('posts')
          .doc(postId)
          .collection('comments')
          .orderBy('createdAt')
          .snapshots()
          .map((s) => s.docs.map(Comment.fromDoc).toList());

  static Future<void> addComment({
    required String stationId,
    required String postId,
    required String text,
    required String username,
  }) {
    final postRef =
        stationsCol.doc(stationId).collection('posts').doc(postId);
    final batch = _fs.batch();
    batch.set(postRef.collection('comments').doc(), {
      'uid': _uid,
      'username': username,
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
    });
    batch.update(postRef, {'commentCount': FieldValue.increment(1)});
    return batch.commit();
  }
}
