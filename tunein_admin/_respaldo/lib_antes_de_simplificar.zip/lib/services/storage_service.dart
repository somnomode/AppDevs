import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'current_user.dart';

/// Subida de archivos (portadas e audios) a Cloud Storage.
///
/// Requiere que el proyecto Firebase esté en el plan Blaze
/// (tiene una cuota gratuita). Si Storage no está activo, las pantallas del
/// Studio permiten pegar una URL de audio/imagen en vez de subir un archivo.
class StorageService {
  StorageService._();

  static final _storage = FirebaseStorage.instance;

  /// Abre el selector de archivos del teléfono y devuelve el archivo
  /// elegido (o null si la persona cancela).
  /// `withData: true` le pide a file_picker que cargue el contenido del
  /// archivo en memoria, para poder subirlo a Storage.
  static Future<PlatformFile?> pickImage() => _pick(FileType.image);

  static Future<PlatformFile?> pickAudio() => _pick(FileType.audio);

  static Future<PlatformFile?> _pick(FileType type) async {
    final result = await FilePicker.platform.pickFiles(
      type: type,
      withData: true,
    );
    if (result == null || result.files.isEmpty) return null;
    return result.files.single;
  }

  /// Sube [file] a `stations/{stationId}/{folder}/...` y devuelve la URL.
  static Future<String> upload({
    required PlatformFile file,
    required String stationId,
    required String folder, // 'images' | 'audio'
  }) async {
    final bytes = file.bytes;
    if (bytes == null) {
      throw StateError('No se pudo leer el archivo seleccionado.');
    }
    final ext = (file.extension ?? '').toLowerCase();
    final name =
        '${DateTime.now().millisecondsSinceEpoch}_${CurrentUser.id}.${ext.isEmpty ? 'bin' : ext}';
    final ref = _storage.ref('stations/$stationId/$folder/$name');
    await ref.putData(bytes, SettableMetadata(contentType: _mime(ext)));
    return ref.getDownloadURL();
  }

  static String? _mime(String ext) => switch (ext) {
        'jpg' || 'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'webp' => 'image/webp',
        'gif' => 'image/gif',
        'mp3' => 'audio/mpeg',
        'm4a' || 'aac' => 'audio/mp4',
        'wav' => 'audio/wav',
        'ogg' => 'audio/ogg',
        _ => null,
      };

  static String messageFor(Object e) {
    if (e is FirebaseException) {
      if (e.code == 'unauthorized') {
        return 'Storage rechazó la subida. Revisa las reglas de Storage.';
      }
      if (e.code == 'unknown' || e.code == 'bucket-not-found' ||
          e.code == 'project-not-found') {
        return 'Cloud Storage no está activo en el proyecto. '
            'Usa una URL o activa Storage (plan Blaze).';
      }
      return e.message ?? 'Error al subir (${e.code}).';
    }
    if (e is StateError) return e.message;
    return 'No se pudo subir el archivo.';
  }
}
