/// Usuario TEMPORAL mientras la app no tiene inicio de sesión.
///
/// Toda la app (favoritos, likes, comentarios, Studio) usa este id fijo.
/// Cuando agreguen el login, solo hay que cambiar `id` y `username` por los
/// del usuario conectado (por ejemplo, FirebaseAuth.instance.currentUser!.uid).
class CurrentUser {
  CurrentUser._();

  static const String id = 'demo-user';
  static const String username = 'usuario_demo';
}
