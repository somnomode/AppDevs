import 'package:flutter/material.dart';

import '../theme/component_tokens.dart';

/// Modos del reproductor.
enum PlayerMode { radio, community }

/// Toggle [ 📻 | 👥 ] del reproductor.
/// Radio activo = naranja (primary). Comunidad activa = teal (secondary).
class ModeToggle extends StatelessWidget {
  const ModeToggle({super.key, required this.mode, required this.onChanged});

  final PlayerMode mode;
  final ValueChanged<PlayerMode> onChanged;

  @override
  Widget build(BuildContext context) {
    final isRadio = mode == PlayerMode.radio;
    final border =
        isRadio ? ModeToggleTokens.radioBorder : ModeToggleTokens.communityBorder;

    Widget segment(PlayerMode m, IconData icon, String label) {
      final active = m == mode;
      final bg = !active
          ? Colors.transparent
          : (m == PlayerMode.radio
              ? ModeToggleTokens.radioActiveBg
              : ModeToggleTokens.communityActiveBg);
      return Semantics(
        button: true,
        selected: active,
        label: label,
        child: GestureDetector(
          onTap: () => onChanged(m),
          behavior: HitTestBehavior.opaque,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            width: ModeToggleTokens.segmentWidth,
            height: ModeToggleTokens.height,
            color: bg,
            child: Icon(
              icon,
              color: active
                  ? ModeToggleTokens.iconActive
                  : ModeToggleTokens.iconInactive,
            ),
          ),
        ),
      );
    }

    return Container(
      decoration: ShapeDecoration(
        shape: StadiumBorder(side: BorderSide(color: border)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          segment(PlayerMode.radio, Icons.radio, 'Radio'),
          segment(PlayerMode.community, Icons.groups, 'Comunidad'),
        ],
      ),
    );
  }
}
