import 'package:flutter/material.dart';

import '../theme/theme.dart';

enum AlertKind { success, error, warning, info }

/// Alertas de feedback — estilo "Opción B" del sistema:
/// fondo oscuro + borde saturado + ícono saturado + texto claro.
void showTuneInAlert(
  BuildContext context,
  String message, {
  AlertKind kind = AlertKind.success,
}) {
  final (Color bg, Color border, Color text, IconData icon) = switch (kind) {
    AlertKind.success => (
        AppSemanticColors.colorSuccessBg,
        AppSemanticColors.colorSuccessBorder,
        AppSemanticColors.colorTextOnSuccess,
        Icons.check_circle_outline,
      ),
    AlertKind.error => (
        AppSemanticColors.colorErrorBg,
        AppSemanticColors.colorErrorBorder,
        AppSemanticColors.colorTextOnError,
        Icons.error_outline,
      ),
    AlertKind.warning => (
        AppSemanticColors.colorWarningBg,
        AppSemanticColors.colorWarningBorder,
        AppSemanticColors.colorTextOnWarning,
        Icons.warning_amber_rounded,
      ),
    AlertKind.info => (
        AppSemanticColors.colorInfoBg,
        AppSemanticColors.colorInfoBorder,
        AppSemanticColors.colorTextOnInfo,
        Icons.info_outline,
      ),
  };

  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    SnackBar(
      backgroundColor: bg,
      duration: const Duration(seconds: 2),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.radiusXs),
        side: BorderSide(color: border),
      ),
      content: Row(
        children: [
          Icon(icon, color: border, size: 20),
          const SizedBox(width: AppGap.gapS8),
          Expanded(
            child: Text(
              message,
              style: AppTypography.body1.copyWith(color: text),
            ),
          ),
        ],
      ),
    ),
  );
}
