import 'package:flutter/material.dart';

import '../screens/profile/history_screen.dart';
import '../screens/profile/profile_screen.dart';
import '../theme/theme.dart';
import 'tunein_logo.dart';

/// Header de las pestañas: logo + historial, ajustes y perfil.
class AppHeader extends StatelessWidget {
  const AppHeader({super.key});

  @override
  Widget build(BuildContext context) {
    void go(Widget page) => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => page),
        );

    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppPadding.paddingXl20,
        AppPadding.paddingL16,
        AppPadding.paddingS8,
        AppPadding.paddingS8,
      ),
      child: Row(
        children: [
          const TuneInLogo(width: 76),
          const Spacer(),
          IconButton(
            tooltip: 'Historial',
            icon: const Icon(Icons.history),
            onPressed: () => go(const HistoryScreen()),
          ),
          IconButton(
            tooltip: 'Ajustes',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => go(const ProfileScreen()),
          ),
          IconButton(
            tooltip: 'Perfil',
            icon: const Icon(Icons.account_circle_outlined),
            onPressed: () => go(const ProfileScreen()),
          ),
        ],
      ),
    );
  }
}
