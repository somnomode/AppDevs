import 'package:flutter/material.dart';

import '../theme/theme.dart';

/// Logo TUNE|IN dibujado con tokens (sin imagen).
/// [width] controla el tamaño; todo escala proporcionalmente.
class TuneInLogo extends StatelessWidget {
  const TuneInLogo({super.key, this.width = 208});

  final double width;

  @override
  Widget build(BuildContext context) {
    final s = width / 208; // diseño base: 208 x 116
    return SizedBox(
      width: width,
      height: 116 * s,
      child: Stack(
        children: [
          // Caja "TUNE" (outlined)
          Positioned(
            left: 0,
            top: 32 * s,
            child: Container(
              width: 134 * s,
              height: 84 * s,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(
                  color: AppSemanticColors.colorBrandPrimary,
                  width: 3 * s,
                ),
              ),
              child: Text(
                'TUNE',
                style: TextStyle(
                  fontFamily: AppTypography.fontFamilyOutfit,
                  fontWeight: FontWeight.w700,
                  fontSize: 36 * s,
                  height: 1,
                  letterSpacing: -0.5 * s,
                  color: AppSemanticColors.colorBrandPrimary,
                ),
              ),
            ),
          ),
          // Cuadro "IN" (relleno)
          Positioned(
            right: 0,
            top: 0,
            child: Container(
              width: 76 * s,
              height: 84 * s,
              alignment: const Alignment(0, -0.45),
              color: AppSemanticColors.colorBrandPrimary,
              child: Text(
                'IN',
                style: TextStyle(
                  fontFamily: AppTypography.fontFamilyOutfit,
                  fontWeight: FontWeight.w700,
                  fontSize: 36 * s,
                  height: 1,
                  color: AppSemanticColors.colorTextOnPrimary,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
