import 'package:flutter/material.dart';

import '../theme/component_tokens.dart';

// =============================================================
// BOTTOM NAVIGATION BAR
// Figma: "Bottom Navigation Bar FINAL" (Componentes · 829:1721)
// Íconos: Material Icons de Google (incluidos en Flutter).
// Medidas ajustadas a una navbar real (M3: 80dp alto, tabs que
// se reparten todo el ancho, targets táctiles ≥ 48dp).
// (Movido desde main.dart sin cambios de diseño.)
// =============================================================

class NavItemData {
  const NavItemData(this.label, this.icon, [IconData? activeIcon])
      : activeIcon = activeIcon ?? icon;
  final String label;
  final IconData icon;
  final IconData activeIcon;
}

class TuneInBottomNavBar extends StatelessWidget {
  const TuneInBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  final int currentIndex;
  final ValueChanged<int> onTap;

  static const items = [
    NavItemData('Home', Icons.home_outlined, Icons.home),
    NavItemData('Library', Icons.bookmarks_outlined, Icons.bookmarks),
    NavItemData('Map', Icons.location_on_outlined, Icons.location_on),
    NavItemData('Search', Icons.search),
  ];

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: BottomNavTokens.bg,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: BottomNavTokens.height,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: BottomNavTokens.paddingH,
            ),
            child: Row(
              children: [
                for (var i = 0; i < items.length; i++)
                  Expanded(
                    child: _NavTabItem(
                      data: items[i],
                      selected: i == currentIndex,
                      onTap: () => onTap(i),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NavTabItem extends StatelessWidget {
  const _NavTabItem({
    required this.data,
    required this.selected,
    required this.onTap,
  });

  final NavItemData data;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color =
        selected ? BottomNavTokens.itemActive : BottomNavTokens.itemInactive;

    // GestureDetector en vez de InkWell: sin splash ni animación al cambiar.
    return Semantics(
      button: true,
      selected: selected,
      label: data.label,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque, // toda la celda es tocable
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              selected ? data.activeIcon : data.icon,
              size: BottomNavTokens.iconSize,
              color: color,
            ),
            const SizedBox(height: BottomNavTokens.iconLabelGap),
            Text(
              data.label,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: BottomNavTokens.label.copyWith(color: color),
            ),
          ],
        ),
      ),
    );
  }
}
