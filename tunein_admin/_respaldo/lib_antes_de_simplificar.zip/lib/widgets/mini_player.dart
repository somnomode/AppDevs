import 'package:flutter/material.dart';

import '../screens/player/player_screen.dart';
import '../services/player_controller.dart';
import '../theme/component_tokens.dart';
import '../theme/theme.dart';
import 'common.dart';

/// Barra "Station Name · Genre · Live" que vive sobre la navbar.
/// Solo aparece cuando hay algo cargado en el reproductor.
class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final player = PlayerController.instance;
    return ListenableBuilder(
      listenable: player,
      builder: (context, _) {
        final np = player.nowPlaying;
        if (np == null) return const SizedBox.shrink();
        return Material(
          color: MiniPlayerTokens.bg,
          child: InkWell(
            onTap: () => PlayerScreen.open(context),
            child: SizedBox(
              height: MiniPlayerTokens.height,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppPadding.paddingXl20,
                ),
                child: Row(
                  children: [
                    CoverImage(
                      url: np.imageUrl,
                      size: MiniPlayerTokens.coverSize,
                      radius: MiniPlayerTokens.radius,
                    ),
                    const SizedBox(width: AppGap.gapM12),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            np.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTypography.sub2.copyWith(
                              color: MiniPlayerTokens.title,
                            ),
                          ),
                          Text(
                            np.isMoment
                                ? '${np.subtitle} · Audio moment'
                                : '${np.station.genre} · Live',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTypography.body2.copyWith(
                              color: MiniPlayerTokens.subtitle,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (player.isLoading)
                      const SizedBox(
                        width: 48,
                        height: 48,
                        child: Padding(
                          padding: EdgeInsets.all(AppPadding.paddingM12),
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    else
                      IconButton(
                        tooltip: player.isPlaying ? 'Pausar' : 'Reproducir',
                        iconSize: 32,
                        color: MiniPlayerTokens.icon,
                        onPressed: player.toggle,
                        icon: Icon(
                          player.isPlaying
                              ? Icons.pause_rounded
                              : Icons.play_arrow_outlined,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
