import 'package:flutter/material.dart';

import '../theme/component_tokens.dart';
import '../theme/theme.dart';

/// Imagen de portada con esquinas redondeadas y placeholder con tokens.
class CoverImage extends StatelessWidget {
  const CoverImage({
    super.key,
    required this.url,
    this.size,
    this.radius = AppRadius.radiusXs,
    this.icon = Icons.radio,
  });

  final String url;
  final double? size; // null = ocupa el espacio disponible
  final double radius;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final placeholder = Container(
      color: AppElevation.elevation4,
      alignment: Alignment.center,
      child: Icon(icon, color: AppSemanticColors.colorTextMuted),
    );
    final image = url.isEmpty
        ? placeholder
        : Image.network(
            url,
            fit: BoxFit.cover,
            errorBuilder: (_, _, _) => placeholder,
            loadingBuilder: (context, child, progress) =>
                progress == null ? child : placeholder,
          );
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: size == null
          ? image
          : SizedBox(width: size, height: size, child: image),
    );
  }
}

/// Variantes del chip de filtro.
enum ChipTone { primary, secondary }

/// Chip de filtro: Radio · Deporte · Podcast / Post · Audio Moments · Tus Favs.
class TuneInChip extends StatelessWidget {
  const TuneInChip({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
    this.tone = ChipTone.primary,
    this.outlinedWhenInactive = false,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final ChipTone tone;
  final bool outlinedWhenInactive;

  @override
  Widget build(BuildContext context) {
    final activeBg = tone == ChipTone.primary
        ? ChipTokens.primaryActiveBg
        : ChipTokens.secondaryActiveBg;
    final activeText = tone == ChipTone.primary
        ? ChipTokens.primaryActiveText
        : ChipTokens.secondaryActiveText;

    final Color bg;
    final Color fg;
    BorderSide side = BorderSide.none;
    if (selected) {
      bg = activeBg;
      fg = activeText;
    } else if (outlinedWhenInactive) {
      bg = Colors.transparent;
      fg = AppSemanticColors.colorTextMain;
      side = const BorderSide(color: ChipTokens.outlinedBorder);
    } else {
      bg = ChipTokens.inactiveBg;
      fg = ChipTokens.inactiveText;
    }

    return Semantics(
      button: true,
      selected: selected,
      child: Material(
        color: bg,
        shape: StadiumBorder(side: side),
        child: InkWell(
          customBorder: const StadiumBorder(),
          onTap: onTap,
          child: Container(
            height: ChipTokens.height,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(
              horizontal: AppPadding.paddingL16,
            ),
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTypography.sub2.copyWith(
                color: fg,
                fontWeight: FontWeight.w400,
                fontSize: 14,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Título de sección ("Recientes", "Musica", "Noticias").
class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key, this.trailing});

  final String text;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppPadding.paddingXl20,
        AppPadding.paddingL16,
        AppPadding.paddingXl20,
        AppPadding.paddingS8,
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              text,
              style: AppTypography.h2.copyWith(
                color: AppSemanticColors.colorTextMain,
              ),
            ),
          ),
          ?trailing,
        ],
      ),
    );
  }
}

/// Fila de lista: Librería, Búsqueda, Recomendaciones.
class StationListTile extends StatelessWidget {
  const StationListTile({
    super.key,
    required this.title,
    required this.subtitle,
    required this.imageUrl,
    this.trailing,
    this.onTap,
    this.filled = false,
    this.highlighted = false,
  });

  final String title;
  final String subtitle;
  final String imageUrl;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool filled; // fondo elevado (búsqueda / recomendaciones)
  final bool highlighted; // está sonando

  @override
  Widget build(BuildContext context) {
    return Material(
      color: filled ? ListItemTokens.bg : Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppPadding.paddingL16,
            vertical: AppPadding.paddingM12,
          ),
          child: Row(
            children: [
              CoverImage(url: imageUrl, size: ListItemTokens.coverSize),
              const SizedBox(width: AppGap.gapM12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.sub2.copyWith(
                        color: highlighted
                            ? AppSemanticColors.colorBrandPrimary
                            : AppSemanticColors.colorTextMain,
                      ),
                    ),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.body2.copyWith(
                        color: AppSemanticColors.colorTextMuted,
                      ),
                    ),
                  ],
                ),
              ),
              ?trailing,
            ],
          ),
        ),
      ),
    );
  }
}

/// Estado vacío / error simple.
class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.message,
    this.action,
  });

  final IconData icon;
  final String title;
  final String? message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppPadding.padding3xl32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: AppSemanticColors.colorTextMuted),
            const SizedBox(height: AppGap.gapL16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: AppTypography.sub1.copyWith(
                color: AppSemanticColors.colorTextMain,
              ),
            ),
            if (message != null) ...[
              const SizedBox(height: AppGap.gapS8),
              Text(
                message!,
                textAlign: TextAlign.center,
                style: AppTypography.body1.copyWith(
                  color: AppSemanticColors.colorTextMuted,
                ),
              ),
            ],
            if (action != null) ...[
              const SizedBox(height: AppGap.gapXl20),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}

/// Spinner centrado.
class Loading extends StatelessWidget {
  const Loading({super.key, this.color});
  final Color? color;

  @override
  Widget build(BuildContext context) => Center(
        child: CircularProgressIndicator(
          color: color ?? AppSemanticColors.colorBrandPrimary,
        ),
      );
}

/// "02:33" en Space Mono (token data).
String formatDuration(Duration? d) {
  if (d == null) return '--:--';
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
}
