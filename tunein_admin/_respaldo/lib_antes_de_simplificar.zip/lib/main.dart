import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';
import 'screens/main_shell.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Conecta la app con el proyecto Firebase (tunein2026sa).
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const TuneInApp());
}

class TuneInApp extends StatelessWidget {
  const TuneInApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TuneIn',
      debugShowCheckedModeBanner: false,
      theme: tuneInAppTheme,
      // Por ahora sin login: la app abre directo en Home.
      // (Las pantallas de login quedaron guardadas en screens/auth/ sin usar.)
      home: const MainShell(),
    );
  }
}
