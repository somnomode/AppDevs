import 'package:flutter/material.dart';

import 'theme.dart';

// =============================================================
// TOKENS DE COMPONENTE (tier 3)
// Cada componente apunta a tokens semánticos / elevación de theme.dart.
// Nunca usar hex directos en las pantallas: siempre pasar por aquí.
// =============================================================

/// bottomnavbar/*  — Figma: "Bottom Navigation Bar FINAL" (829:1721)
class BottomNavTokens {
  static const bg = AppColors.neutral800; // bottom-navbar-bg #07091A
  static const itemActive = AppSemanticColors.colorBrandPrimary;
  static const itemInactive = AppSemanticColors.colorTextMain;
  static const double height = 72;
  static const double iconSize = 24;
  static const double iconLabelGap = AppGap.gapXs4;
  static const double paddingH = AppPadding.paddingS8;
  static const TextStyle label = TextStyle(
    fontFamily: AppTypography.fontFamilyOutfit,
    fontSize: 12,
    fontWeight: FontWeight.w400,
    letterSpacing: 0.4,
    height: 16 / 12,
  );
}

/// miniplayer/*  — barra "Station Name · Genre · Live" sobre la navbar
class MiniPlayerTokens {
  static const bg = AppElevation.elevation4; // neutral-500
  static const title = AppSemanticColors.colorTextMain;
  static const subtitle = AppSemanticColors.colorTextMuted;
  static const icon = AppSemanticColors.colorTextMain;
  static const double height = 64;
  static const double coverSize = 48;
  static const double radius = AppRadius.radiusXs;
}

/// player/*  — pantalla "Reproductor"
class PlayerTokens {
  static const bg = AppElevation.elevation2; // neutral-700
  static const coverRadius = AppRadius.radiusM;
  static const trackActive = AppSemanticColors.colorBrandPrimary;
  static const trackInactive = AppColors.neutral50;
  static const playButtonBg = AppElevation.elevation4;
  static const playButtonIcon = AppSemanticColors.colorTextMain;
  static const double playButtonSize = 88;
  static const double controlIconSize = 48;
  static const handle = AppColors.neutral100;
}

/// modetoggle/*  — toggle Radio | Comunidad del reproductor
class ModeToggleTokens {
  static const radioActiveBg = AppSemanticColors.colorBrandPrimary;
  static const radioBorder = AppSemanticColors.colorBrandPrimary;
  static const communityActiveBg = AppSemanticColors.colorBrandSecondary;
  static const communityBorder = AppSemanticColors.colorBrandSecondary;
  static const iconActive = AppSemanticColors.colorTextOnPrimary;
  static const iconInactive = AppSemanticColors.colorTextMain;
  static const double height = 40;
  static const double segmentWidth = 62;
}

/// social/*  — sección comunidad (Post · Audio Moments · Tus Favs)
/// El teal (secondary) es el color de esta sección.
class SocialTokens {
  static const bg = AppElevation.elevation2;
  static const cardBg = AppElevation.elevation5; // neutral-400
  static const accent = AppSemanticColors.colorBrandSecondary;
  static const accentText = AppSemanticColors.colorTextOnSecondary;
  static const trackActive = AppSemanticColors.colorBrandSecondary;
  static const trackInactive = AppColors.secondary100;
  static const divider = AppColors.neutral200;
  static const inputBg = AppColors.neutral300;
  static const double cardRadius = AppRadius.radiusXs;
  static const double coverSize = 112;
}

/// chip/*  — filtros (Radio · Deporte · Podcast)
class ChipTokens {
  static const primaryActiveBg = AppSemanticColors.colorBrandPrimary;
  static const primaryActiveText = AppSemanticColors.colorTextOnPrimary;
  static const secondaryActiveBg = AppSemanticColors.colorBrandSecondary;
  static const secondaryActiveText = AppSemanticColors.colorTextOnSecondary;
  static const inactiveBg = AppColors.neutral50;
  static const inactiveText = AppColors.neutral900;
  static const outlinedBorder = AppColors.neutral200;
  static const double height = 32;
}

/// listitem/*  — filas de Librería, Búsqueda y Recomendaciones
class ListItemTokens {
  static const bg = AppElevation.elevation4;
  static const divider = AppSemanticColors.colorBorderSubtle;
  static const coverRadius = AppRadius.radiusXs;
  static const double coverSize = 48;
  static const favorite = AppSemanticColors.colorBrandPrimary;
}

/// input/*  — campos de texto (login / registro)
class InputTokens {
  static const border = AppSemanticColors.colorBrandPrimary;
  static const borderFocused = AppColors.primary300;
  static const borderError = AppSemanticColors.colorErrorBorder;
  static const text = AppSemanticColors.colorTextMain;
  static const placeholder = AppColors.neutral300;
  static const label = AppSemanticColors.colorTextMain;
  static const double height = 48;
}

/// sheet/*  — bottom sheets (opciones, recomendaciones)
class SheetTokens {
  static const bg = AppElevation.elevation2;
  static const tileBg = AppElevation.elevation4;
  static const double radius = AppRadius.radiusM;
}
