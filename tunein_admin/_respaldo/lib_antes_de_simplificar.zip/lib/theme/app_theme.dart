import 'package:flutter/material.dart';

import 'component_tokens.dart';
import 'theme.dart';

/// Tema final de la app: parte de `tuneInTheme` (theme.dart) y le suma
/// los temas de componentes que faltaban (inputs, botón outlined, snackbar,
/// sheets, slider, etc.). theme.dart queda intacto como fuente de tokens.
final ThemeData tuneInAppTheme = tuneInTheme.copyWith(
  inputDecorationTheme: InputDecorationThemeData(
    filled: false,
    isDense: true,
    contentPadding: const EdgeInsets.symmetric(
      horizontal: AppPadding.paddingXl20,
      vertical: AppPadding.paddingM12,
    ),
    hintStyle: AppTypography.sub1.copyWith(color: InputTokens.placeholder),
    labelStyle: AppTypography.sub2.copyWith(color: InputTokens.label),
    errorStyle: AppTypography.caption.copyWith(
      color: AppSemanticColors.colorErrorBorder,
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppRadius.radiusL),
      borderSide: const BorderSide(color: InputTokens.border),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppRadius.radiusL),
      borderSide: const BorderSide(color: InputTokens.borderFocused, width: 2),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppRadius.radiusL),
      borderSide: const BorderSide(color: InputTokens.borderError),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppRadius.radiusL),
      borderSide: const BorderSide(color: InputTokens.borderError, width: 2),
    ),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(AppRadius.radiusL),
    ),
  ),

  // BOTÓN SECUNDARIO (outlined) — "Iniciar sesión" / "Registrarse" inactivos
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: ButtonStyle(
      foregroundColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.disabled)) {
          return AppSemanticColors.colorTextDisabled;
        }
        return AppSemanticColors.colorTextMain;
      }),
      side: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.disabled)) {
          return const BorderSide(color: AppSemanticColors.colorTextDisabled);
        }
        return const BorderSide(color: AppSemanticColors.colorBrandPrimary);
      }),
      overlayColor: WidgetStatePropertyAll(
        AppSemanticColors.colorBrandPrimary.withValues(alpha: 0.12),
      ),
      textStyle: WidgetStatePropertyAll(
        AppTypography.sub2.copyWith(fontWeight: FontWeight.w600),
      ),
      padding: const WidgetStatePropertyAll(
        EdgeInsets.symmetric(
          horizontal: AppPadding.padding2xl24,
          vertical: AppPadding.paddingS8,
        ),
      ),
      minimumSize: const WidgetStatePropertyAll(
        Size(64, AppSpacing.spacing4xl40),
      ),
      shape: const WidgetStatePropertyAll(StadiumBorder()),
    ),
  ),

  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(
      foregroundColor: AppSemanticColors.colorTextMain,
      textStyle: AppTypography.body2,
      padding: const EdgeInsets.symmetric(horizontal: AppPadding.paddingXs4),
      minimumSize: const Size(0, 32),
      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
    ),
  ),

  iconTheme: const IconThemeData(color: AppSemanticColors.colorTextMain),

  textSelectionTheme: const TextSelectionThemeData(
    cursorColor: AppSemanticColors.colorBrandPrimary,
    selectionColor: AppColors.primary700,
    selectionHandleColor: AppSemanticColors.colorBrandPrimary,
  ),

  dividerTheme: const DividerThemeData(
    color: AppSemanticColors.colorBorderSubtle,
    thickness: 1,
    space: 1,
  ),

  bottomSheetTheme: const BottomSheetThemeData(
    backgroundColor: SheetTokens.bg,
    surfaceTintColor: Colors.transparent,
    showDragHandle: false,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(SheetTokens.radius),
      ),
    ),
  ),

  snackBarTheme: const SnackBarThemeData(
    behavior: SnackBarBehavior.floating,
    elevation: 0,
  ),

  dialogTheme: DialogThemeData(
    backgroundColor: AppElevation.elevation3,
    surfaceTintColor: Colors.transparent,
    titleTextStyle: AppTypography.h3.copyWith(
      color: AppSemanticColors.colorTextMain,
    ),
    contentTextStyle: AppTypography.body1.copyWith(
      color: AppSemanticColors.colorTextBody,
    ),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppRadius.radiusM),
    ),
  ),

  progressIndicatorTheme: const ProgressIndicatorThemeData(
    color: AppSemanticColors.colorBrandPrimary,
  ),

  sliderTheme: const SliderThemeData(
    trackHeight: 4,
    activeTrackColor: PlayerTokens.trackActive,
    inactiveTrackColor: PlayerTokens.trackInactive,
    thumbColor: PlayerTokens.trackActive,
    overlayShape: RoundSliderOverlayShape(overlayRadius: 12),
    thumbShape: RoundSliderThumbShape(enabledThumbRadius: 6),
  ),
);
