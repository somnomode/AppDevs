import 'package:cloud_firestore/cloud_firestore.dart';

/// Categorías = chips del Home (Radio · Deporte · Podcast).
class StationCategory {
  static const radio = 'radio';
  static const deporte = 'deporte';
  static const podcast = 'podcast';

  static const all = [radio, deporte, podcast];

  static String label(String c) => switch (c) {
        radio => 'Radio',
        deporte => 'Deporte',
        podcast => 'Podcast',
        _ => c,
      };
}

/// Una emisora. Colección: `stations/{id}`
///
/// La transmisión en vivo se SIMULA con un archivo de audio (`audioUrl`).
class Station {
  const Station({
    required this.id,
    required this.name,
    required this.genre,
    required this.category,
    required this.location,
    required this.imageUrl,
    required this.audioUrl,
    this.frequency = '',
    this.description = '',
    this.lat,
    this.lng,
    this.ownerUid,
  });

  final String id;
  final String name;
  final String genre; // "Música", "Noticias", "Deporte"...
  final String category; // StationCategory
  final String location; // "Santiago, Chile"
  final String frequency; // "88.5 FM"
  final String description;
  final String imageUrl;
  final String audioUrl;
  final double? lat;
  final double? lng;
  final String? ownerUid;

  bool get hasLocation => lat != null && lng != null;

  /// "Música · Santiago, Chile"
  String get subtitle =>
      [genre, location].where((s) => s.isNotEmpty).join(' · ');

  factory Station.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const {};
    return Station(
      id: doc.id,
      name: d['name'] as String? ?? 'Sin nombre',
      genre: d['genre'] as String? ?? '',
      category: d['category'] as String? ?? StationCategory.radio,
      location: d['location'] as String? ?? '',
      frequency: d['frequency'] as String? ?? '',
      description: d['description'] as String? ?? '',
      imageUrl: d['imageUrl'] as String? ?? '',
      audioUrl: d['audioUrl'] as String? ?? '',
      lat: (d['lat'] as num?)?.toDouble(),
      lng: (d['lng'] as num?)?.toDouble(),
      ownerUid: d['ownerUid'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'nameLower': name.toLowerCase(),
        'genre': genre,
        'category': category,
        'location': location,
        'frequency': frequency,
        'description': description,
        'imageUrl': imageUrl,
        'audioUrl': audioUrl,
        'lat': lat,
        'lng': lng,
        'ownerUid': ownerUid,
      };
}
