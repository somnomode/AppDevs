import 'package:cloud_firestore/cloud_firestore.dart';

DateTime _date(dynamic v) =>
    v is Timestamp ? v.toDate() : DateTime.fromMillisecondsSinceEpoch(0);

/// Publicación de una emisora (pestaña "Post").
/// Colección: `stations/{stationId}/posts/{postId}`
class Post {
  const Post({
    required this.id,
    required this.stationId,
    required this.title,
    required this.summary,
    required this.imageUrl,
    required this.createdAt,
    this.likeCount = 0,
    this.commentCount = 0,
  });

  final String id;
  final String stationId;
  final String title;
  final String summary;
  final String imageUrl;
  final DateTime createdAt;
  final int likeCount;
  final int commentCount;

  factory Post.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const {};
    return Post(
      id: doc.id,
      stationId: d['stationId'] as String? ?? doc.reference.parent.parent!.id,
      title: d['title'] as String? ?? '',
      summary: d['summary'] as String? ?? '',
      imageUrl: d['imageUrl'] as String? ?? '',
      createdAt: _date(d['createdAt']),
      likeCount: (d['likeCount'] as num?)?.toInt() ?? 0,
      commentCount: (d['commentCount'] as num?)?.toInt() ?? 0,
    );
  }
}

/// Clip de audio subido por una emisora (pestaña "Audio Moments").
/// Colección: `stations/{stationId}/moments/{momentId}`
class AudioMoment {
  const AudioMoment({
    required this.id,
    required this.stationId,
    required this.title,
    required this.audioUrl,
    required this.imageUrl,
    required this.createdAt,
    this.durationMs,
    this.likeCount = 0,
  });

  final String id;
  final String stationId;
  final String title;
  final String audioUrl;
  final String imageUrl;
  final DateTime createdAt;
  final int? durationMs;
  final int likeCount;

  Duration? get duration =>
      durationMs == null ? null : Duration(milliseconds: durationMs!);

  factory AudioMoment.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const {};
    return AudioMoment(
      id: doc.id,
      stationId: d['stationId'] as String? ?? doc.reference.parent.parent!.id,
      title: d['title'] as String? ?? '',
      audioUrl: d['audioUrl'] as String? ?? '',
      imageUrl: d['imageUrl'] as String? ?? '',
      createdAt: _date(d['createdAt']),
      durationMs: (d['durationMs'] as num?)?.toInt(),
      likeCount: (d['likeCount'] as num?)?.toInt() ?? 0,
    );
  }
}

/// Comentario en un post.
/// Colección: `stations/{stationId}/posts/{postId}/comments/{commentId}`
class Comment {
  const Comment({
    required this.id,
    required this.uid,
    required this.username,
    required this.text,
    required this.createdAt,
  });

  final String id;
  final String uid;
  final String username;
  final String text;
  final DateTime createdAt;

  factory Comment.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const {};
    return Comment(
      id: doc.id,
      uid: d['uid'] as String? ?? '',
      username: d['username'] as String? ?? 'usuario',
      text: d['text'] as String? ?? '',
      createdAt: _date(d['createdAt']),
    );
  }
}

/// Tipo de contenido que se puede likear/guardar.
enum LikeType { post, moment }

/// Like / guardado del usuario (pestaña "Tus Favs").
/// Colección: `users/{uid}/likes/{itemId}`
/// Guarda una copia del contenido para listar sin consultas extra.
class LikedItem {
  const LikedItem({
    required this.itemId,
    required this.stationId,
    required this.type,
    required this.title,
    required this.summary,
    required this.imageUrl,
    required this.audioUrl,
    this.durationMs,
  });

  final String itemId;
  final String stationId;
  final LikeType type;
  final String title;
  final String summary;
  final String imageUrl;
  final String audioUrl;
  final int? durationMs;

  factory LikedItem.fromPost(Post p) => LikedItem(
        itemId: p.id,
        stationId: p.stationId,
        type: LikeType.post,
        title: p.title,
        summary: p.summary,
        imageUrl: p.imageUrl,
        audioUrl: '',
      );

  factory LikedItem.fromMoment(AudioMoment m) => LikedItem(
        itemId: m.id,
        stationId: m.stationId,
        type: LikeType.moment,
        title: m.title,
        summary: '',
        imageUrl: m.imageUrl,
        audioUrl: m.audioUrl,
        durationMs: m.durationMs,
      );

  factory LikedItem.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const {};
    return LikedItem(
      itemId: doc.id,
      stationId: d['stationId'] as String? ?? '',
      type: d['type'] == 'moment' ? LikeType.moment : LikeType.post,
      title: d['title'] as String? ?? '',
      summary: d['summary'] as String? ?? '',
      imageUrl: d['imageUrl'] as String? ?? '',
      audioUrl: d['audioUrl'] as String? ?? '',
      durationMs: (d['durationMs'] as num?)?.toInt(),
    );
  }

  Post toPost() => Post(
        id: itemId,
        stationId: stationId,
        title: title,
        summary: summary,
        imageUrl: imageUrl,
        createdAt: DateTime.now(),
      );

  AudioMoment toMoment() => AudioMoment(
        id: itemId,
        stationId: stationId,
        title: title,
        audioUrl: audioUrl,
        imageUrl: imageUrl,
        createdAt: DateTime.now(),
        durationMs: durationMs,
      );

  Map<String, dynamic> toMap() => {
        'stationId': stationId,
        'type': type.name,
        'title': title,
        'summary': summary,
        'imageUrl': imageUrl,
        'audioUrl': audioUrl,
        'durationMs': durationMs,
        'likedAt': FieldValue.serverTimestamp(),
      };
}
