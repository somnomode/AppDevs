import 'package:cloud_firestore/cloud_firestore.dart';

/// Perfil del usuario. Colección: `users/{uid}`
///
/// Si `stationId` no es null, el usuario es una EMISORA y ve el Studio
/// para subir posts y audio moments.
class AppUser {
  const AppUser({
    required this.uid,
    required this.firstName,
    required this.lastName,
    required this.username,
    required this.email,
    this.stationId,
  });

  final String uid;
  final String firstName;
  final String lastName;
  final String username;
  final String email;
  final String? stationId;

  bool get isBroadcaster => stationId != null && stationId!.isNotEmpty;
  String get fullName => '$firstName $lastName'.trim();

  factory AppUser.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const {};
    return AppUser(
      uid: doc.id,
      firstName: d['firstName'] as String? ?? '',
      lastName: d['lastName'] as String? ?? '',
      username: d['username'] as String? ?? 'usuario',
      email: d['email'] as String? ?? '',
      stationId: d['stationId'] as String?,
    );
  }
}
