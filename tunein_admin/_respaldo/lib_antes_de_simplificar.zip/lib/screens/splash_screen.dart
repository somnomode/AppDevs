import 'package:flutter/material.dart';

import '../theme/theme.dart';
import '../widgets/tunein_logo.dart';

/// Pantalla de carga (Figma: primer frame de "Patrones de diseño").
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: AppSemanticColors.colorSurfaceBg,
      body: Center(child: TuneInLogo(width: 240)),
    );
  }
}
