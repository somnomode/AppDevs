import 'package:flutter/material.dart';

import '../../models/station.dart';
import '../../services/app_nav.dart';
import '../../services/player_controller.dart';
import '../../services/store.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/common.dart';
import '../../widgets/tunein_alert.dart';
import 'now_playing_view.dart';

/// Hoja "Recomendaciones" (Figma: frame con lista bajo el reproductor).
/// Primero emisoras de la misma categoría, luego el resto.
void showRecommendations(BuildContext context, Station current) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (context) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.75,
      maxChildSize: 0.95,
      minChildSize: 0.4,
      builder: (context, scroll) {
        final all = Store.stations.value ?? const <Station>[];
        final others = all.where((s) => s.id != current.id).toList()
          ..sort((a, b) {
            final aa = a.category == current.category ? 0 : 1;
            final bb = b.category == current.category ? 0 : 1;
            return aa.compareTo(bb);
          });
        return Column(
          children: [
            const SizedBox(height: AppGap.gapM12),
            Container(
              width: 172,
              height: 4,
              decoration: BoxDecoration(
                color: PlayerTokens.handle,
                borderRadius: BorderRadius.circular(AppRadius.radiusFull),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(AppPadding.paddingM12),
              child: Text(
                'Recomendaciones',
                style: AppTypography.sub1.copyWith(
                  color: AppSemanticColors.colorTextMain,
                ),
              ),
            ),
            Expanded(
              child: ListView.separated(
                controller: scroll,
                itemCount: others.length,
                separatorBuilder: (_, _) =>
                    const SizedBox(height: AppGap.gapS8),
                itemBuilder: (context, i) {
                  final s = others[i];
                  return StationListTile(
                    filled: true,
                    title: s.name,
                    subtitle: s.subtitle,
                    imageUrl: s.imageUrl,
                    trailing: const Icon(Icons.play_arrow_outlined),
                    onTap: () {
                      Navigator.of(context).pop();
                      PlayerController.instance.playStation(s, queue: all);
                    },
                  );
                },
              ),
            ),
          ],
        );
      },
    ),
  );
}

/// Hoja de opciones "⋮" (Figma: "Frame 209").
void showStationOptions(BuildContext context, Station station) {
  final player = PlayerController.instance;

  void soon(BuildContext sheetCtx, String what) {
    Navigator.of(sheetCtx).pop();
    showTuneInAlert(context, '$what: próximamente', kind: AlertKind.info);
  }

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (sheetCtx) => SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          AppPadding.paddingL16,
          AppPadding.paddingS8,
          AppPadding.paddingL16,
          AppPadding.paddingL16,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            IconButton(
              tooltip: 'Cerrar',
              icon: const Icon(Icons.close),
              onPressed: () => Navigator.of(sheetCtx).pop(),
            ),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        station.name,
                        style: AppTypography.h3.copyWith(
                          color: AppSemanticColors.colorTextMain,
                        ),
                      ),
                      Text(
                        station.subtitle,
                        style: AppTypography.body2.copyWith(
                          color: AppSemanticColors.colorTextMuted,
                        ),
                      ),
                    ],
                  ),
                ),
                ValueListenableBuilder<Set<String>>(
                  valueListenable: Store.favoriteIds,
                  builder: (_, favs, _) {
                    final fav = favs.contains(station.id);
                    return IconButton(
                      tooltip: fav ? 'Quitar de favoritos' : 'Agregar a favoritos',
                      color: fav ? ListItemTokens.favorite : null,
                      icon: Icon(fav ? Icons.favorite : Icons.favorite_border),
                      onPressed: () => toggleFavorite(context, station.id, !fav),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: AppGap.gapM12),
            Row(
              children: [
                _BigAction(
                  icon: Icons.directions_car_outlined,
                  label: 'Modo auto',
                  onTap: () => soon(sheetCtx, 'Modo auto'),
                ),
                const SizedBox(width: AppGap.gapS8),
                _BigAction(
                  icon: Icons.cast,
                  label: 'Castear',
                  onTap: () => soon(sheetCtx, 'Castear'),
                ),
                const SizedBox(width: AppGap.gapS8),
                _BigAction(
                  icon: Icons.share_outlined,
                  label: 'Compartir',
                  onTap: () {
                    Navigator.of(sheetCtx).pop();
                    shareStation(context, station);
                  },
                ),
              ],
            ),
            const SizedBox(height: AppGap.gapS8),
            _OptionTile(
              icon: Icons.devices_outlined,
              label: 'Controlar dispositivos',
              onTap: () => soon(sheetCtx, 'Controlar dispositivos'),
            ),
            _OptionTile(
              icon: Icons.info_outline,
              label: 'Información',
              onTap: () {
                Navigator.of(sheetCtx).pop();
                _showInfo(context, station);
              },
            ),
            _OptionTile(
              icon: Icons.block,
              label: 'Bloquear',
              onTap: () => soon(sheetCtx, 'Bloquear'),
            ),
            _OptionTile(
              icon: Icons.report_gmailerrorred,
              label: 'Reportar',
              onTap: () {
                Navigator.of(sheetCtx).pop();
                showTuneInAlert(context, 'Gracias, revisaremos esta emisora.',
                    kind: AlertKind.info);
              },
            ),
            if (station.hasLocation)
              _OptionTile(
                icon: Icons.location_on_outlined,
                label: 'Encontrar en el mapa',
                onTap: () {
                  Navigator.of(sheetCtx).pop();
                  Navigator.of(context).popUntil((r) => r.isFirst);
                  AppNav.showOnMap(station);
                },
              ),
            _OptionTile(
              icon: Icons.bedtime_outlined,
              label: player.sleepAt == null
                  ? 'Timer de Sueño'
                  : 'Timer de Sueño (activo)',
              onTap: () {
                Navigator.of(sheetCtx).pop();
                _pickSleepTimer(context);
              },
            ),
          ],
        ),
      ),
    ),
  );
}

void _showInfo(BuildContext context, Station s) {
  showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(s.name),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (s.description.isNotEmpty) Text(s.description),
          const SizedBox(height: AppGap.gapM12),
          Text('Género: ${s.genre}'),
          Text('Ubicación: ${s.location}'),
          if (s.frequency.isNotEmpty)
            Text(
              s.frequency,
              style: AppTypography.data1.copyWith(
                color: AppSemanticColors.colorBrandPrimary,
              ),
            ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(),
          child: const Text('Cerrar'),
        ),
      ],
    ),
  );
}

void _pickSleepTimer(BuildContext context) {
  final player = PlayerController.instance;
  const options = [15, 30, 45, 60];
  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(AppPadding.paddingL16),
            child: Text(
              'Timer de Sueño',
              style: AppTypography.sub1.copyWith(
                color: AppSemanticColors.colorTextMain,
              ),
            ),
          ),
          for (final m in options)
            _OptionTile(
              icon: Icons.timer_outlined,
              label: '$m minutos',
              onTap: () {
                player.setSleepTimer(Duration(minutes: m));
                Navigator.of(ctx).pop();
                showTuneInAlert(context, 'Se pausará en $m minutos');
              },
            ),
          if (player.sleepAt != null)
            _OptionTile(
              icon: Icons.timer_off_outlined,
              label: 'Desactivar',
              onTap: () {
                player.setSleepTimer(null);
                Navigator.of(ctx).pop();
              },
            ),
          const SizedBox(height: AppGap.gapS8),
        ],
      ),
    ),
  );
}

class _BigAction extends StatelessWidget {
  const _BigAction({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Material(
        color: SheetTokens.tileBg,
        borderRadius: BorderRadius.circular(AppRadius.radiusS),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppRadius.radiusS),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: AppPadding.paddingM12),
            child: Column(
              children: [
                Icon(icon),
                const SizedBox(height: AppGap.gapXs4),
                Text(
                  label,
                  style: AppTypography.body1.copyWith(
                    color: AppSemanticColors.colorTextMain,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _OptionTile extends StatelessWidget {
  const _OptionTile({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: AppSemanticColors.colorTextMain),
      title: Text(
        label,
        style: AppTypography.sub2.copyWith(
          color: AppSemanticColors.colorTextMain,
          fontWeight: FontWeight.w400,
        ),
      ),
      onTap: onTap,
    );
  }
}
