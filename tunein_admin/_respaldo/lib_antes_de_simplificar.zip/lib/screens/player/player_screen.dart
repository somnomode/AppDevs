import 'package:flutter/material.dart';

import '../../models/station.dart';
import '../../services/player_controller.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/mode_toggle.dart';
import '../../widgets/tunein_alert.dart';
import '../community/community_view.dart';
import 'now_playing_view.dart';
import 'player_sheets.dart';

/// Reproduce [station] y abre el reproductor.
Future<void> openStation(
  BuildContext context,
  Station station, {
  List<Station>? queue,
  PlayerMode mode = PlayerMode.radio,
}) async {
  final player = PlayerController.instance;
  final future = player.playStation(station, queue: queue);
  PlayerScreen.open(context, mode: mode);
  await future;
  if (player.error != null && context.mounted) {
    showTuneInAlert(context, player.error!, kind: AlertKind.error);
  }
}

/// Reproductor a pantalla completa con toggle Radio | Comunidad.
/// Figma: frames "Reproductor" (radio) y "soc2/3/4" (comunidad).
class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, this.initialMode = PlayerMode.radio});

  final PlayerMode initialMode;

  static void open(BuildContext context, {PlayerMode mode = PlayerMode.radio}) {
    Navigator.of(context).push(
      PageRouteBuilder<void>(
        pageBuilder: (_, _, _) => PlayerScreen(initialMode: mode),
        transitionsBuilder: (_, anim, _, child) => SlideTransition(
          position: Tween(begin: const Offset(0, 1), end: Offset.zero)
              .chain(CurveTween(curve: Curves.easeOutCubic))
              .animate(anim),
          child: child,
        ),
      ),
    );
  }

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late PlayerMode _mode = widget.initialMode;

  @override
  Widget build(BuildContext context) {
    final player = PlayerController.instance;
    return ListenableBuilder(
      listenable: player,
      builder: (context, _) {
        final np = player.nowPlaying;
        if (np == null) {
          return const Scaffold(backgroundColor: PlayerTokens.bg);
        }
        return Scaffold(
          backgroundColor: PlayerTokens.bg,
          body: SafeArea(
            child: Column(
              children: [
                _TopBar(
                  mode: _mode,
                  onMode: (m) => setState(() => _mode = m),
                  onMore: () => showStationOptions(context, np.station),
                ),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: _mode == PlayerMode.radio
                        ? NowPlayingView(key: const ValueKey('radio'), np: np)
                        : CommunityView(
                            key: ValueKey('community-${np.station.id}'),
                            station: np.station,
                          ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.mode,
    required this.onMode,
    required this.onMore,
  });

  final PlayerMode mode;
  final ValueChanged<PlayerMode> onMode;
  final VoidCallback onMore;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppPadding.paddingXs4,
        vertical: AppPadding.paddingS8,
      ),
      child: Row(
        children: [
          IconButton(
            tooltip: 'Cerrar',
            iconSize: 32,
            icon: const Icon(Icons.keyboard_arrow_down),
            onPressed: () => Navigator.of(context).pop(),
          ),
          Expanded(
            child: Center(child: ModeToggle(mode: mode, onChanged: onMode)),
          ),
          IconButton(
            tooltip: 'Más opciones',
            icon: const Icon(Icons.more_vert),
            onPressed: onMore,
          ),
        ],
      ),
    );
  }
}
