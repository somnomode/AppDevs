import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../models/station.dart';
import '../../services/db.dart';
import '../../services/player_controller.dart';
import '../../services/store.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/common.dart';
import '../../widgets/tunein_alert.dart';
import 'player_sheets.dart';

/// Vista "Radio" del reproductor (Figma: "Reproductor").
class NowPlayingView extends StatelessWidget {
  const NowPlayingView({super.key, required this.np});

  final NowPlaying np;

  @override
  Widget build(BuildContext context) {
    final player = PlayerController.instance;
    return LayoutBuilder(
      builder: (context, constraints) {
        // La portada se achica en pantallas bajas.
        final byWidth = constraints.maxWidth - AppPadding.padding2xl24 * 2;
        final byHeight = constraints.maxHeight * 0.42;
        final coverSize = math.max(96.0, math.min(byWidth, byHeight));
        return Column(
          children: [
            const SizedBox(height: AppGap.gapL16),
            Center(
              child: CoverImage(
                url: np.imageUrl,
                size: coverSize,
                radius: PlayerTokens.coverRadius,
              ),
            ),
            const SizedBox(height: AppGap.gapXl20),
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppPadding.padding3xl32,
              ),
              child: Column(
                children: [
                  _TitleRow(np: np),
                  const SizedBox(height: AppGap.gapM12),
                  const _ProgressBar(),
                ],
              ),
            ),
            const Spacer(),
            _Controls(player: player),
            const Spacer(),
            _RecommendationsHandle(
              onOpen: () => showRecommendations(context, np.station),
            ),
          ],
        );
      },
    );
  }
}

class _TitleRow extends StatelessWidget {
  const _TitleRow({required this.np});
  final NowPlaying np;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                np.isMoment
                    ? np.title
                    : [np.title, np.station.frequency]
                        .where((s) => s.isNotEmpty && s != 'Podcast')
                        .join(' '),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: AppTypography.h3.copyWith(
                  color: AppSemanticColors.colorTextMain,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                np.subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTypography.body2.copyWith(
                  color: AppSemanticColors.colorTextMuted,
                ),
              ),
            ],
          ),
        ),
        IconButton(
          tooltip: 'Compartir',
          icon: const Icon(Icons.share_outlined),
          onPressed: () => shareStation(context, np.station),
        ),
        ValueListenableBuilder<Set<String>>(
          valueListenable: Store.favoriteIds,
          builder: (context, favs, _) {
            final fav = favs.contains(np.station.id);
            return IconButton(
              tooltip: fav ? 'Quitar de favoritos' : 'Agregar a favoritos',
              color: fav ? ListItemTokens.favorite : null,
              icon: Icon(fav ? Icons.favorite : Icons.favorite_border),
              onPressed: () => toggleFavorite(context, np.station.id, !fav),
            );
          },
        ),
      ],
    );
  }
}

/// Guarda / quita una emisora de la Librería con feedback.
Future<void> toggleFavorite(
  BuildContext context,
  String stationId,
  bool value,
) async {
  try {
    await Db.setFavorite(stationId, value);
    if (context.mounted) {
      showTuneInAlert(
        context,
        value ? 'Agregado a favoritos' : 'Quitado de favoritos',
        kind: value ? AlertKind.success : AlertKind.info,
      );
    }
  } catch (_) {
    if (context.mounted) {
      showTuneInAlert(context, 'No se pudo guardar.', kind: AlertKind.error);
    }
  }
}

/// "Compartir": copia un texto al portapapeles.
Future<void> shareStation(BuildContext context, Station station) async {
  final name = station.name;
  final freq = station.frequency == 'Podcast' ? '' : station.frequency;
  await Clipboard.setData(
    ClipboardData(text: 'Estoy escuchando $name $freq en TuneIn 📻'),
  );
  if (context.mounted) {
    showTuneInAlert(context, 'Enlace copiado al portapapeles',
        kind: AlertKind.info);
  }
}

/// Barra de progreso naranja con tiempos en Space Mono.
class _ProgressBar extends StatelessWidget {
  const _ProgressBar();

  @override
  Widget build(BuildContext context) {
    final player = PlayerController.instance;
    return StreamBuilder<Duration?>(
      stream: player.durationStream,
      initialData: player.duration,
      builder: (context, durSnap) {
        final total = durSnap.data ?? Duration.zero;
        return StreamBuilder<Duration>(
          stream: player.positionStream,
          initialData: player.position,
          builder: (context, posSnap) {
            var pos = posSnap.data ?? Duration.zero;
            if (pos > total) pos = total;
            final max = total.inMilliseconds.toDouble();
            return Column(
              children: [
                SizedBox(
                  height: 20,
                  child: Slider(
                    value: max == 0 ? 0 : pos.inMilliseconds.toDouble(),
                    max: max == 0 ? 1 : max,
                    onChanged: max == 0
                        ? null
                        : (v) =>
                            player.seek(Duration(milliseconds: v.round())),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(formatDuration(pos), style: _time),
                    Text(
                      total == Duration.zero ? '--:--' : formatDuration(total),
                      style: _time,
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }

  static final _time =
      AppTypography.data2.copyWith(color: AppSemanticColors.colorTextMain);
}

class _Controls extends StatelessWidget {
  const _Controls({required this.player});
  final PlayerController player;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
          tooltip: 'Anterior',
          iconSize: PlayerTokens.controlIconSize,
          onPressed: player.canSkip ? player.previous : null,
          icon: const Icon(Icons.skip_previous_outlined),
        ),
        const SizedBox(width: AppGap.gapXl20),
        Material(
          color: PlayerTokens.playButtonBg,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: player.toggle,
            child: SizedBox(
              width: PlayerTokens.playButtonSize,
              height: PlayerTokens.playButtonSize,
              child: player.isLoading
                  ? const Padding(
                      padding: EdgeInsets.all(AppPadding.padding3xl32),
                      child: CircularProgressIndicator(strokeWidth: 3),
                    )
                  : Icon(
                      player.isPlaying
                          ? Icons.pause_rounded
                          : Icons.play_arrow_outlined,
                      size: 56,
                      color: PlayerTokens.playButtonIcon,
                      semanticLabel: player.isPlaying ? 'Pausar' : 'Reproducir',
                    ),
            ),
          ),
        ),
        const SizedBox(width: AppGap.gapXl20),
        IconButton(
          tooltip: 'Siguiente',
          iconSize: PlayerTokens.controlIconSize,
          onPressed: player.canSkip ? player.next : null,
          icon: const Icon(Icons.skip_next_outlined),
        ),
      ],
    );
  }
}

class _RecommendationsHandle extends StatelessWidget {
  const _RecommendationsHandle({required this.onOpen});
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onOpen,
      onVerticalDragEnd: (d) {
        if ((d.primaryVelocity ?? 0) < 0) onOpen();
      },
      child: Padding(
        padding: const EdgeInsets.only(
          top: AppPadding.paddingM12,
          bottom: AppPadding.paddingXl20,
        ),
        child: Column(
          children: [
            Container(
              width: 172,
              height: 4,
              decoration: BoxDecoration(
                color: PlayerTokens.handle,
                borderRadius: BorderRadius.circular(AppRadius.radiusFull),
              ),
            ),
            const SizedBox(height: AppGap.gapM12),
            Text(
              'Recomendaciones',
              style: AppTypography.sub1.copyWith(
                color: AppSemanticColors.colorTextMain,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
