import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../../services/storage_service.dart';
import '../../theme/theme.dart';

enum MediaKind { image, audio }

/// Controlador de un campo de archivo: archivo local O URL pegada.
class MediaFieldController extends ChangeNotifier {
  MediaFieldController(this.kind);

  final MediaKind kind;
  PlatformFile? file;
  final url = TextEditingController();

  bool get isEmpty => file == null && url.text.trim().isEmpty;

  void setFile(PlatformFile? f) {
    file = f;
    if (f != null) url.clear();
    notifyListeners();
  }

  /// Sube el archivo (si hay) y devuelve la URL final.
  Future<String> resolve(String stationId) async {
    if (file != null) {
      return StorageService.upload(
        file: file!,
        stationId: stationId,
        folder: kind == MediaKind.image ? 'images' : 'audio',
      );
    }
    return url.text.trim();
  }

  @override
  void dispose() {
    url.dispose();
    super.dispose();
  }
}

/// UI: botón "Elegir archivo" + campo "o pega una URL".
class MediaField extends StatelessWidget {
  const MediaField({
    super.key,
    required this.label,
    required this.controller,
    this.required = true,
  });

  final String label;
  final MediaFieldController controller;
  final bool required;

  @override
  Widget build(BuildContext context) {
    final isImage = controller.kind == MediaKind.image;
    return ListenableBuilder(
      listenable: Listenable.merge([controller, controller.url]),
      builder: (context, _) {
        final f = controller.file;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              required ? label : '$label (opcional)',
              style: AppTypography.sub2.copyWith(
                color: AppSemanticColors.colorTextMain,
              ),
            ),
            const SizedBox(height: AppGap.gapS8),
            Row(
              children: [
                OutlinedButton.icon(
                  onPressed: () async {
                    final picked = isImage
                        ? await StorageService.pickImage()
                        : await StorageService.pickAudio();
                    if (picked != null) controller.setFile(picked);
                  },
                  icon: Icon(isImage ? Icons.image_outlined : Icons.audio_file),
                  label: Text(f == null ? 'Elegir archivo' : 'Cambiar'),
                ),
                const SizedBox(width: AppGap.gapS8),
                if (f != null)
                  Expanded(
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            f.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTypography.body2.copyWith(
                              color: AppSemanticColors.colorTextMuted,
                            ),
                          ),
                        ),
                        IconButton(
                          tooltip: 'Quitar',
                          icon: const Icon(Icons.close, size: 18),
                          onPressed: () => controller.setFile(null),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
            if (f == null) ...[
              const SizedBox(height: AppGap.gapS8),
              TextField(
                controller: controller.url,
                keyboardType: TextInputType.url,
                style: AppTypography.body1.copyWith(
                  color: AppSemanticColors.colorTextMain,
                ),
                decoration: InputDecoration(
                  hintText: isImage
                      ? 'o pega la URL de una imagen'
                      : 'o pega la URL de un .mp3',
                  hintStyle: AppTypography.body1.copyWith(
                    color: AppColors.neutral300,
                  ),
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}
