import 'package:flutter/material.dart';

import '../../models/social.dart';
import '../../models/station.dart';
import '../../services/db.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/common.dart';
import '../../widgets/tunein_alert.dart';
import '../player/player_screen.dart';
import 'new_content_screen.dart';

/// Studio de la emisora: publicar posts y audio moments, y borrarlos.
class StudioScreen extends StatelessWidget {
  const StudioScreen({super.key, required this.stationId});

  final String stationId;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Station?>(
      stream: Db.station(stationId),
      builder: (context, snap) {
        final station = snap.data;
        return DefaultTabController(
          length: 2,
          child: Scaffold(
            appBar: AppBar(
              title: const Text('Studio'),
              bottom: const TabBar(
                indicatorColor: SocialTokens.accent,
                labelColor: SocialTokens.accent,
                unselectedLabelColor: AppSemanticColors.colorTextMuted,
                tabs: [
                  Tab(text: 'Posts'),
                  Tab(text: 'Audio Moments'),
                ],
              ),
            ),
            floatingActionButton: station == null
                ? null
                : FloatingActionButton.extended(
                    backgroundColor: SocialTokens.accent,
                    foregroundColor: SocialTokens.accentText,
                    onPressed: () => _newContent(context, station),
                    icon: const Icon(Icons.add),
                    label: const Text('Publicar'),
                  ),
            body: station == null
                ? (snap.connectionState == ConnectionState.waiting
                    ? const Loading()
                    : const EmptyState(
                        icon: Icons.error_outline,
                        title: 'No encontramos tu emisora',
                      ))
                : Column(
                    children: [
                      StationListTile(
                        title: station.name,
                        subtitle: station.subtitle,
                        imageUrl: station.imageUrl,
                        trailing: TextButton(
                          onPressed: () => openStation(context, station),
                          child: const Text('Escuchar'),
                        ),
                      ),
                      const Divider(),
                      Expanded(
                        child: TabBarView(
                          children: [
                            _PostsList(stationId: station.id),
                            _MomentsList(stationId: station.id),
                          ],
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  void _newContent(BuildContext context, Station station) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.article_outlined),
              title: const Text('Nuevo post'),
              subtitle: const Text('Imagen + título + resumen'),
              onTap: () {
                Navigator.of(ctx).pop();
                Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => NewContentScreen(
                    station: station,
                    kind: NewContentKind.post,
                  ),
                ));
              },
            ),
            ListTile(
              leading: const Icon(Icons.graphic_eq),
              title: const Text('Nuevo audio moment'),
              subtitle: const Text('Un clip de tu transmisión'),
              onTap: () {
                Navigator.of(ctx).pop();
                Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => NewContentScreen(
                    station: station,
                    kind: NewContentKind.moment,
                  ),
                ));
              },
            ),
          ],
        ),
      ),
    );
  }
}

Future<bool> _confirmDelete(BuildContext context, String what) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text('¿Borrar $what?'),
      content: const Text('Esta acción no se puede deshacer.'),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: const Text('Cancelar'),
        ),
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(true),
          child: const Text(
            'Borrar',
            style: TextStyle(color: AppSemanticColors.colorErrorBorder),
          ),
        ),
      ],
    ),
  );
  return ok == true;
}

class _PostsList extends StatefulWidget {
  const _PostsList({required this.stationId});
  final String stationId;

  @override
  State<_PostsList> createState() => _PostsListState();
}

class _PostsListState extends State<_PostsList> {
  late final _stream = Db.posts(widget.stationId);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Post>>(
      stream: _stream,
      builder: (context, snap) {
        if (!snap.hasData) return const Loading(color: SocialTokens.accent);
        final list = snap.data!;
        if (list.isEmpty) {
          return const EmptyState(
            icon: Icons.article_outlined,
            title: 'Aún no publicas posts',
            message: 'Toca "Publicar" para crear el primero.',
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.only(bottom: 96),
          itemCount: list.length,
          separatorBuilder: (_, _) => const Divider(),
          itemBuilder: (context, i) {
            final p = list[i];
            return StationListTile(
              title: p.title,
              subtitle:
                  '♥ ${p.likeCount}  ·  💬 ${p.commentCount}  ·  ${p.summary}',
              imageUrl: p.imageUrl,
              trailing: IconButton(
                tooltip: 'Borrar',
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  if (await _confirmDelete(context, 'el post')) {
                    await Db.deletePost(widget.stationId, p.id);
                    if (context.mounted) {
                      showTuneInAlert(context, 'Post borrado',
                          kind: AlertKind.info);
                    }
                  }
                },
              ),
            );
          },
        );
      },
    );
  }
}

class _MomentsList extends StatefulWidget {
  const _MomentsList({required this.stationId});
  final String stationId;

  @override
  State<_MomentsList> createState() => _MomentsListState();
}

class _MomentsListState extends State<_MomentsList> {
  late final _stream = Db.moments(widget.stationId);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<AudioMoment>>(
      stream: _stream,
      builder: (context, snap) {
        if (!snap.hasData) return const Loading(color: SocialTokens.accent);
        final list = snap.data!;
        if (list.isEmpty) {
          return const EmptyState(
            icon: Icons.graphic_eq,
            title: 'Aún no subes audio moments',
            message: 'Comparte los mejores momentos de tu transmisión.',
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.only(bottom: 96),
          itemCount: list.length,
          separatorBuilder: (_, _) => const Divider(),
          itemBuilder: (context, i) {
            final m = list[i];
            return StationListTile(
              title: m.title,
              subtitle: '♥ ${m.likeCount}  ·  ${formatDuration(m.duration)}',
              imageUrl: m.imageUrl,
              trailing: IconButton(
                tooltip: 'Borrar',
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  if (await _confirmDelete(context, 'el audio moment')) {
                    await Db.deleteMoment(widget.stationId, m.id);
                    if (context.mounted) {
                      showTuneInAlert(context, 'Audio moment borrado',
                          kind: AlertKind.info);
                    }
                  }
                },
              ),
            );
          },
        );
      },
    );
  }
}
