import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import '../../models/station.dart';
import '../../services/db.dart';
import '../../services/storage_service.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/tunein_alert.dart';
import '../auth/auth_widgets.dart';
import 'media_field.dart';

enum NewContentKind { post, moment }

/// Crear un post (imagen + texto) o un audio moment (clip de audio).
class NewContentScreen extends StatefulWidget {
  const NewContentScreen({
    super.key,
    required this.station,
    required this.kind,
  });

  final Station station;
  final NewContentKind kind;

  @override
  State<NewContentScreen> createState() => _NewContentScreenState();
}

class _NewContentScreenState extends State<NewContentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _summary = TextEditingController();
  final _image = MediaFieldController(MediaKind.image);
  final _audio = MediaFieldController(MediaKind.audio);
  bool _saving = false;

  bool get _isPost => widget.kind == NewContentKind.post;

  @override
  void dispose() {
    _title.dispose();
    _summary.dispose();
    _image.dispose();
    _audio.dispose();
    super.dispose();
  }

  /// Lee la duración del clip ya subido (para mostrar 2:00 en la tarjeta).
  Future<int?> _durationOf(String url) async {
    final probe = AudioPlayer();
    try {
      final d = await probe.setUrl(url);
      return d?.inMilliseconds;
    } catch (_) {
      return null;
    } finally {
      await probe.dispose();
    }
  }

  Future<void> _publish() async {
    if (!_formKey.currentState!.validate()) return;
    if (_isPost && _image.isEmpty) {
      showTuneInAlert(context, 'Agrega una imagen al post.',
          kind: AlertKind.warning);
      return;
    }
    if (!_isPost && _audio.isEmpty) {
      showTuneInAlert(context, 'Agrega el audio del clip.',
          kind: AlertKind.warning);
      return;
    }
    setState(() => _saving = true);
    final id = widget.station.id;
    try {
      final imageUrl = _image.isEmpty ? '' : await _image.resolve(id);
      if (_isPost) {
        await Db.addPost(
          stationId: id,
          title: _title.text.trim(),
          summary: _summary.text.trim(),
          imageUrl: imageUrl,
        );
      } else {
        final audioUrl = await _audio.resolve(id);
        await Db.addMoment(
          stationId: id,
          title: _title.text.trim(),
          audioUrl: audioUrl,
          imageUrl: imageUrl,
          durationMs: await _durationOf(audioUrl),
        );
      }
      if (!mounted) return;
      showTuneInAlert(context, _isPost ? 'Post publicado' : 'Clip publicado');
      Navigator.of(context).pop();
    } catch (e) {
      if (mounted) {
        showTuneInAlert(context, StorageService.messageFor(e),
            kind: AlertKind.error);
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const gap = SizedBox(height: AppGap.gapL16);
    return Scaffold(
      appBar: AppBar(
        title: Text(_isPost ? 'Nuevo post' : 'Nuevo audio moment'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(AppPadding.paddingXl20),
          children: [
            LabeledField(
              label: 'Título',
              hint: _isPost ? 'Detrás de cámaras' : 'Desayunando con huesitos Cap 4',
              controller: _title,
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Escribe un título' : null,
            ),
            gap,
            if (_isPost) ...[
              LabeledField(
                label: 'Resumen',
                hint: 'Una línea que invite a comentar',
                controller: _summary,
              ),
              gap,
            ],
            if (!_isPost) ...[
              MediaField(label: 'Audio del clip', controller: _audio),
              gap,
            ],
            MediaField(
              label: _isPost ? 'Imagen' : 'Portada',
              controller: _image,
              required: _isPost,
            ),
            const SizedBox(height: AppSpacing.spacing3xl32),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: SocialTokens.accent,
                foregroundColor: SocialTokens.accentText,
              ),
              onPressed: _saving ? null : _publish,
              child: _saving
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('PUBLICAR'),
            ),
          ],
        ),
      ),
    );
  }
}
