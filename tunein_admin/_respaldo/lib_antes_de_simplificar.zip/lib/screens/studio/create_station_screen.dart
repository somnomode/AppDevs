import 'package:flutter/material.dart';

import '../../models/station.dart';
import '../../services/db.dart';
import '../../services/storage_service.dart';
import '../../theme/theme.dart';
import '../../widgets/common.dart';
import '../../widgets/tunein_alert.dart';
import '../auth/auth_widgets.dart';
import 'media_field.dart';
import 'studio_screen.dart';

/// Formulario para que un usuario se convierta en emisora.
class CreateStationScreen extends StatefulWidget {
  const CreateStationScreen({super.key});

  @override
  State<CreateStationScreen> createState() => _CreateStationScreenState();
}

class _CreateStationScreenState extends State<CreateStationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _genre = TextEditingController();
  final _location = TextEditingController();
  final _frequency = TextEditingController();
  final _description = TextEditingController();
  final _lat = TextEditingController();
  final _lng = TextEditingController();
  final _cover = MediaFieldController(MediaKind.image);
  final _audio = MediaFieldController(MediaKind.audio);
  String _category = StationCategory.radio;
  bool _saving = false;

  @override
  void dispose() {
    for (final c in [
      _name, _genre, _location, _frequency, _description, _lat, _lng,
    ]) {
      c.dispose();
    }
    _cover.dispose();
    _audio.dispose();
    super.dispose();
  }

  String? _required(String? v) =>
      (v == null || v.trim().isEmpty) ? 'Campo obligatorio' : null;

  String? _coord(String? v, double limit) {
    if (v == null || v.trim().isEmpty) return null;
    final d = double.tryParse(v.trim().replaceAll(',', '.'));
    if (d == null || d.abs() > limit) return 'Número inválido';
    return null;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_audio.isEmpty) {
      showTuneInAlert(context, 'Agrega el audio de la transmisión.',
          kind: AlertKind.warning);
      return;
    }
    setState(() => _saving = true);
    try {
      final id = Db.stationsCol.doc().id;
      final imageUrl = _cover.isEmpty ? '' : await _cover.resolve(id);
      final audioUrl = await _audio.resolve(id);
      double? parse(TextEditingController c) =>
          double.tryParse(c.text.trim().replaceAll(',', '.'));
      await Db.createStation(
        Station(
          id: id,
          name: _name.text.trim(),
          genre: _genre.text.trim(),
          category: _category,
          location: _location.text.trim(),
          frequency: _frequency.text.trim(),
          description: _description.text.trim(),
          imageUrl: imageUrl,
          audioUrl: audioUrl,
          lat: parse(_lat),
          lng: parse(_lng),
        ),
        id: id,
      );
      if (!mounted) return;
      showTuneInAlert(context, '¡Tu emisora está al aire!');
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => StudioScreen(stationId: id)),
      );
    } catch (e) {
      if (mounted) {
        showTuneInAlert(context, StorageService.messageFor(e),
            kind: AlertKind.error);
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const gap = SizedBox(height: AppGap.gapL16);
    return Scaffold(
      appBar: AppBar(title: const Text('Crear emisora')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(AppPadding.paddingXl20),
          children: [
            LabeledField(
              label: 'Nombre de la emisora',
              hint: 'Radio Cordillera',
              controller: _name,
              validator: _required,
            ),
            gap,
            Text(
              'Categoría',
              style: AppTypography.sub2.copyWith(
                color: AppSemanticColors.colorTextMain,
              ),
            ),
            const SizedBox(height: AppGap.gapS8),
            Row(
              children: [
                for (final c in StationCategory.all) ...[
                  Expanded(
                    child: TuneInChip(
                      label: StationCategory.label(c),
                      selected: _category == c,
                      outlinedWhenInactive: true,
                      onTap: () => setState(() => _category = c),
                    ),
                  ),
                  if (c != StationCategory.all.last)
                    const SizedBox(width: AppGap.gapS8),
                ],
              ],
            ),
            gap,
            LabeledField(
              label: 'Género',
              hint: 'Música, Noticias, Deporte…',
              controller: _genre,
              validator: _required,
            ),
            gap,
            LabeledField(
              label: 'Ciudad',
              hint: 'Santiago, Chile',
              controller: _location,
              validator: _required,
            ),
            gap,
            LabeledField(
              label: 'Frecuencia',
              hint: '88.5 FM',
              controller: _frequency,
            ),
            gap,
            LabeledField(
              label: 'Descripción',
              hint: 'Cuéntale a tu audiencia de qué se trata',
              controller: _description,
            ),
            gap,
            Row(
              children: [
                Expanded(
                  child: LabeledField(
                    label: 'Latitud',
                    hint: '-33.45',
                    controller: _lat,
                    keyboardType: const TextInputType.numberWithOptions(
                      signed: true,
                      decimal: true,
                    ),
                    validator: (v) => _coord(v, 90),
                  ),
                ),
                const SizedBox(width: AppGap.gapM12),
                Expanded(
                  child: LabeledField(
                    label: 'Longitud',
                    hint: '-70.66',
                    controller: _lng,
                    keyboardType: const TextInputType.numberWithOptions(
                      signed: true,
                      decimal: true,
                    ),
                    validator: (v) => _coord(v, 180),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: AppGap.gapXs4),
              child: Text(
                'Opcional: con coordenadas tu emisora aparece en el mapa.',
                style: AppTypography.caption.copyWith(
                  color: AppSemanticColors.colorTextMuted,
                ),
              ),
            ),
            gap,
            MediaField(
              label: 'Logo / portada',
              controller: _cover,
              required: false,
            ),
            gap,
            MediaField(
              label: 'Audio de la transmisión (simulada)',
              controller: _audio,
            ),
            const SizedBox(height: AppSpacing.spacing3xl32),
            FilledButton(
              onPressed: _saving ? null : _save,
              child: _saving
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('CREAR EMISORA'),
            ),
          ],
        ),
      ),
    );
  }
}
