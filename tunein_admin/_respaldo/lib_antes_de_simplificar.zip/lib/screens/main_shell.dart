import 'package:flutter/material.dart';

import '../services/app_nav.dart';
import '../services/store.dart';
import '../widgets/bottom_nav_bar.dart';
import '../widgets/mini_player.dart';
import 'home/home_screen.dart';
import 'library/library_screen.dart';
import 'map/map_screen.dart';
import 'search/search_screen.dart';

/// Estructura principal: pestañas + mini player + bottom nav.
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  @override
  void initState() {
    super.initState();
    AppNav.tab.value = AppNav.home;
    Store.start();
  }

  @override
  void dispose() {
    Store.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: AppNav.tab,
      builder: (context, index, _) {
        return Scaffold(
          body: SafeArea(
            bottom: false,
            child: IndexedStack(
              index: index,
              children: const [
                HomeScreen(),
                LibraryScreen(),
                MapScreen(),
                SearchScreen(),
              ],
            ),
          ),
          bottomNavigationBar: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const MiniPlayer(),
              TuneInBottomNavBar(
                currentIndex: index,
                onTap: (i) => AppNav.tab.value = i,
              ),
            ],
          ),
        );
      },
    );
  }
}
