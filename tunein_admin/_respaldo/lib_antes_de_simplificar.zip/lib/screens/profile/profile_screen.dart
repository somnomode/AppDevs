import 'package:flutter/material.dart';

import '../../models/app_user.dart';
import '../../services/current_user.dart';
import '../../services/seed_data.dart';
import '../../services/store.dart';
import '../../theme/theme.dart';
import '../../widgets/tunein_alert.dart';
import '../studio/create_station_screen.dart';
import '../studio/studio_screen.dart';

/// Perfil + ajustes: Studio de emisora, datos demo, cerrar sesión.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _seeding = false;

  Future<void> _seed() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cargar datos demo'),
        content: const Text(
          'Se crearán 12 emisoras con posts, comentarios y audio moments '
          'de ejemplo. Si ya existen, se sobrescriben.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('CARGAR'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _seeding = true);
    try {
      final n = await SeedData.run();
      if (mounted) showTuneInAlert(context, '$n emisoras cargadas');
    } catch (e) {
      if (mounted) {
        showTuneInAlert(context, 'Error al cargar: $e', kind: AlertKind.error);
      }
    } finally {
      if (mounted) setState(() => _seeding = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Perfil')),
      body: ValueListenableBuilder<AppUser?>(
        valueListenable: Store.me,
        builder: (context, me, _) {
          final email = me?.email ?? 'Modo demo · sin inicio de sesión';
          return ListView(
            padding: const EdgeInsets.all(AppPadding.paddingXl20),
            children: [
              Row(
                children: [
                  const CircleAvatar(
                    radius: 32,
                    backgroundColor: AppElevation.elevation4,
                    child: Icon(Icons.person, size: 36),
                  ),
                  const SizedBox(width: AppGap.gapL16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          (me?.fullName.isNotEmpty ?? false)
                              ? me!.fullName
                              : 'Usuario demo',
                          style: AppTypography.h3.copyWith(
                            color: AppSemanticColors.colorTextMain,
                          ),
                        ),
                        Text(
                            '@${me?.username ?? CurrentUser.username}',
                            style: AppTypography.body1.copyWith(
                              color: AppSemanticColors.colorBrandPrimary,
                            ),
                          ),
                        Text(
                          email,
                          style: AppTypography.body2.copyWith(
                            color: AppSemanticColors.colorTextMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.spacing3xl32),
              _sectionLabel('EMISORA'),
              _Tile(
                icon: Icons.mic_none,
                title: me?.isBroadcaster == true
                    ? 'Studio de mi emisora'
                    : 'Crear mi emisora',
                subtitle: me?.isBroadcaster == true
                    ? 'Sube posts y audio moments'
                    : 'Conviértete en emisora y publica clips',
                onTap: () {
                  final page = me?.isBroadcaster == true
                      ? StudioScreen(stationId: me!.stationId!)
                      : const CreateStationScreen();
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => page),
                  );
                },
              ),
              const SizedBox(height: AppGap.gapXl20),
              _sectionLabel('DESARROLLO'),
              _Tile(
                icon: Icons.dataset_outlined,
                title: 'Cargar datos demo',
                subtitle: 'Emisoras, posts y audio moments de ejemplo',
                trailing: _seeding
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : null,
                onTap: _seeding ? null : _seed,
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _sectionLabel(String t) => Padding(
        padding: const EdgeInsets.only(bottom: AppGap.gapS8),
        child: Text(
          t,
          style: AppTypography.overline.copyWith(
            color: AppSemanticColors.colorTextMuted,
          ),
        ),
      );
}

class _Tile extends StatelessWidget {
  const _Tile({
    required this.icon,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppElevation.elevation2,
      borderRadius: BorderRadius.circular(AppRadius.radiusS),
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        onTap: onTap,
        leading: Icon(icon, color: AppSemanticColors.colorBrandPrimary),
        title: Text(
          title,
          style: AppTypography.sub2.copyWith(
            color: AppSemanticColors.colorTextMain,
          ),
        ),
        subtitle: subtitle == null
            ? null
            : Text(
                subtitle!,
                style: AppTypography.body2.copyWith(
                  color: AppSemanticColors.colorTextMuted,
                ),
              ),
        trailing: trailing ?? const Icon(Icons.chevron_right),
      ),
    );
  }
}
