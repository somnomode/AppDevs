import 'package:flutter/material.dart';

import '../../services/store.dart';
import '../../widgets/common.dart';
import '../player/player_screen.dart';

/// Historial: emisoras escuchadas recientemente.
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Historial')),
      body: ListenableBuilder(
        listenable: Listenable.merge([Store.stations, Store.recentIds]),
        builder: (context, _) {
          if (Store.stations.value == null) return const Loading();
          final recents = Store.recentStations;
          if (recents.isEmpty) {
            return const EmptyState(
              icon: Icons.history,
              title: 'Aún no escuchas nada',
              message: 'Las emisoras que reproduzcas aparecerán aquí.',
            );
          }
          return ListView.separated(
            itemCount: recents.length,
            separatorBuilder: (_, _) => const Divider(),
            itemBuilder: (context, i) {
              final s = recents[i];
              return StationListTile(
                title: s.name,
                subtitle: s.subtitle,
                imageUrl: s.imageUrl,
                trailing: const Icon(Icons.play_arrow_outlined),
                onTap: () => openStation(context, s, queue: recents),
              );
            },
          );
        },
      ),
    );
  }
}
