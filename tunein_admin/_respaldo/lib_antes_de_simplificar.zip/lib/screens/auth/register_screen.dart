import 'package:flutter/material.dart';

import '../../services/auth_service.dart';
import '../../theme/theme.dart';
import '../../widgets/tunein_alert.dart';
import '../../widgets/tunein_logo.dart';
import 'auth_widgets.dart';

/// Registro (Figma: frames "Bienvenido a TUNE IN").
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstName = TextEditingController();
  final _lastName = TextEditingController();
  final _email = TextEditingController();
  final _username = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _loading = false;

  List<TextEditingController> get _all =>
      [_firstName, _lastName, _email, _username, _password, _confirm];

  bool get _ready => _all.every((c) => c.text.trim().isNotEmpty);

  @override
  void initState() {
    super.initState();
    for (final c in _all) {
      c.addListener(_refresh);
    }
  }

  void _refresh() => setState(() {});

  @override
  void dispose() {
    for (final c in _all) {
      c.dispose();
    }
    super.dispose();
  }

  String? _required(String? v) =>
      (v == null || v.trim().isEmpty) ? 'Campo obligatorio' : null;

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await AuthService.register(
        firstName: _firstName.text,
        lastName: _lastName.text,
        email: _email.text,
        username: _username.text,
        password: _password.text,
      );
      // Ya hay sesión: cerramos esta pantalla y AuthGate muestra la app.
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (e) {
      if (mounted) {
        showTuneInAlert(context, AuthService.messageFor(e),
            kind: AlertKind.error);
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const gap = SizedBox(height: AppGap.gapM12);
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            AppPadding.padding3xl32,
            0,
            AppPadding.padding3xl32,
            AppPadding.padding3xl32,
          ),
          child: AutofillGroup(
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Bienvenido a',
                    style: AppTypography.sub2.copyWith(
                      color: AppSemanticColors.colorTextMain,
                    ),
                  ),
                  const SizedBox(height: AppGap.gapS8),
                  const Center(child: TuneInLogo(width: 170)),
                  const SizedBox(height: AppSpacing.spacing3xl32),
                  LabeledField(
                    label: 'Nombres',
                    hint: 'Sofía Paz',
                    controller: _firstName,
                    autofillHints: const [AutofillHints.givenName],
                    validator: _required,
                  ),
                  gap,
                  LabeledField(
                    label: 'Apellidos',
                    hint: 'Ortiz Hernández',
                    controller: _lastName,
                    autofillHints: const [AutofillHints.familyName],
                    validator: _required,
                  ),
                  gap,
                  LabeledField(
                    label: 'Correo',
                    hint: 'correo@udd.cl',
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    autofillHints: const [AutofillHints.email],
                    validator: (v) => (v == null || !v.contains('@'))
                        ? 'Correo no válido'
                        : null,
                  ),
                  gap,
                  LabeledField(
                    label: 'Nombre de usuario',
                    hint: 'sofiapaz',
                    controller: _username,
                    autofillHints: const [AutofillHints.username],
                    validator: (v) {
                      if (v == null || v.trim().length < 3) {
                        return 'Mínimo 3 caracteres';
                      }
                      if (v.contains(' ')) return 'Sin espacios';
                      return null;
                    },
                  ),
                  gap,
                  LabeledField(
                    label: 'Contraseña',
                    controller: _password,
                    obscure: true,
                    autofillHints: const [AutofillHints.newPassword],
                    validator: (v) => (v == null || v.length < 6)
                        ? 'Mínimo 6 caracteres'
                        : null,
                  ),
                  gap,
                  LabeledField(
                    label: 'Confirmar contraseña',
                    controller: _confirm,
                    obscure: true,
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) => _submit(),
                    validator: (v) => v != _password.text
                        ? 'Las contraseñas no coinciden'
                        : null,
                  ),
                  const SizedBox(height: AppSpacing.spacing2xl24),
                  FormSubmitButton(
                    label: 'Registrarse',
                    ready: _ready,
                    loading: _loading,
                    onPressed: _submit,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
