import 'package:flutter/material.dart';

import '../../services/auth_service.dart';
import '../../theme/theme.dart';
import '../../widgets/tunein_alert.dart';
import '../../widgets/tunein_logo.dart';
import 'auth_widgets.dart';
import 'register_screen.dart';

/// Iniciar sesión (Figma: frames "Pantalla de inicio").
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _loading = false;

  bool get _ready => _email.text.trim().isNotEmpty && _password.text.isNotEmpty;

  @override
  void initState() {
    super.initState();
    _email.addListener(_refresh);
    _password.addListener(_refresh);
  }

  void _refresh() => setState(() {});

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await AuthService.signIn(_email.text, _password.text);
      // AuthGate cambia a la app automáticamente.
    } catch (e) {
      if (mounted) {
        showTuneInAlert(context, AuthService.messageFor(e),
            kind: AlertKind.error);
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _forgot() async {
    final email = _email.text.trim();
    if (!email.contains('@')) {
      showTuneInAlert(context, 'Escribe tu correo en "Usuario" primero.',
          kind: AlertKind.info);
      return;
    }
    try {
      await AuthService.sendPasswordReset(email);
      if (mounted) {
        showTuneInAlert(context, 'Te enviamos un correo para recuperarla.');
      }
    } catch (e) {
      if (mounted) {
        showTuneInAlert(context, AuthService.messageFor(e),
            kind: AlertKind.error);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(
              horizontal: AppPadding.padding3xl32,
              vertical: AppPadding.padding2xl24,
            ),
            child: AutofillGroup(
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Center(child: TuneInLogo()),
                    const SizedBox(height: AppSpacing.spacing8xl64),
                    LabeledField(
                      label: 'Usuario',
                      hint: 'correo@udd.cl',
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      autofillHints: const [AutofillHints.email],
                      validator: (v) => (v == null || !v.contains('@'))
                          ? 'Ingresa tu correo'
                          : null,
                    ),
                    const SizedBox(height: AppGap.gapL16),
                    LabeledField(
                      label: 'Contraseña',
                      controller: _password,
                      obscure: true,
                      textInputAction: TextInputAction.done,
                      autofillHints: const [AutofillHints.password],
                      onSubmitted: (_) => _submit(),
                      validator: (v) => (v == null || v.isEmpty)
                          ? 'Ingresa tu contraseña'
                          : null,
                    ),
                    const SizedBox(height: AppGap.gapS8),
                    TextButton(
                      onPressed: _forgot,
                      child: Text(
                        '¿Olvidaste tu contraseña?',
                        style: AppTypography.data2.copyWith(
                          color: AppSemanticColors.colorTextMain,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => const RegisterScreen(),
                        ),
                      ),
                      child: Text(
                        'Registrarse',
                        style: AppTypography.body2.copyWith(
                          color: AppSemanticColors.colorTextMain,
                          fontWeight: FontWeight.w600,
                          decoration: TextDecoration.underline,
                          decorationColor: AppSemanticColors.colorTextMain,
                        ),
                      ),
                    ),
                    const SizedBox(height: AppGap.gapXl20),
                    FormSubmitButton(
                      label: 'Iniciar sesión',
                      ready: _ready,
                      loading: _loading,
                      onPressed: _submit,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
