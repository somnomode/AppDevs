import 'package:flutter/material.dart';

import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';

/// Campo con etiqueta arriba (Figma: "Usuario", "Contraseña", etc.).
class LabeledField extends StatefulWidget {
  const LabeledField({
    super.key,
    required this.label,
    required this.controller,
    this.hint,
    this.obscure = false,
    this.keyboardType,
    this.textInputAction = TextInputAction.next,
    this.validator,
    this.onSubmitted,
    this.autofillHints,
  });

  final String label;
  final TextEditingController controller;
  final String? hint;
  final bool obscure;
  final TextInputType? keyboardType;
  final TextInputAction textInputAction;
  final FormFieldValidator<String>? validator;
  final ValueChanged<String>? onSubmitted;
  final Iterable<String>? autofillHints;

  @override
  State<LabeledField> createState() => _LabeledFieldState();
}

class _LabeledFieldState extends State<LabeledField> {
  late bool _hidden = widget.obscure;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.label,
          style: AppTypography.sub2.copyWith(color: InputTokens.label),
        ),
        const SizedBox(height: AppGap.gapS8),
        TextFormField(
          controller: widget.controller,
          obscureText: _hidden,
          keyboardType: widget.keyboardType,
          textInputAction: widget.textInputAction,
          validator: widget.validator,
          onFieldSubmitted: widget.onSubmitted,
          autofillHints: widget.autofillHints,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          style: AppTypography.sub1.copyWith(color: InputTokens.text),
          decoration: InputDecoration(
            hintText: widget.hint,
            suffixIcon: widget.obscure
                ? IconButton(
                    tooltip: _hidden ? 'Mostrar' : 'Ocultar',
                    onPressed: () => setState(() => _hidden = !_hidden),
                    icon: Icon(
                      _hidden
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: AppSemanticColors.colorTextMuted,
                    ),
                  )
                : null,
          ),
        ),
      ],
    );
  }
}

/// Botón principal del form: outlined mientras falten datos,
/// naranja (filled) cuando el formulario está completo.
class FormSubmitButton extends StatelessWidget {
  const FormSubmitButton({
    super.key,
    required this.label,
    required this.ready,
    required this.loading,
    required this.onPressed,
  });

  final String label;
  final bool ready;
  final bool loading;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final child = loading
        ? const SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: AppSemanticColors.colorTextOnPrimary,
            ),
          )
        : Text(label);
    final style = ButtonStyle(
      textStyle: WidgetStatePropertyAll(
        AppTypography.sub2.copyWith(fontWeight: FontWeight.w600),
      ),
    );
    return SizedBox(
      width: double.infinity,
      child: ready
          ? FilledButton(
              style: style,
              onPressed: loading ? null : onPressed,
              child: child,
            )
          : OutlinedButton(onPressed: onPressed, child: child),
    );
  }
}
