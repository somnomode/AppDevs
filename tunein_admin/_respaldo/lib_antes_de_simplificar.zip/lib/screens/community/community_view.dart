import 'package:flutter/material.dart';

import '../../models/social.dart';
import '../../models/station.dart';
import '../../services/db.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/common.dart';
import 'social_cards.dart';

enum _Tab { posts, moments, favs }

/// Vista "Comunidad" del reproductor (teal).
/// Figma: "soc2" (Post), "soc3" (Audio Moments), "Tus favs".
class CommunityView extends StatefulWidget {
  const CommunityView({super.key, required this.station});

  final Station station;

  @override
  State<CommunityView> createState() => _CommunityViewState();
}

class _CommunityViewState extends State<CommunityView> {
  _Tab _tab = _Tab.posts;

  // Streams creados una vez (no en build) para no re-suscribirse.
  late final Stream<List<Post>> _posts = Db.posts(widget.station.id);
  late final Stream<List<AudioMoment>> _moments = Db.moments(widget.station.id);
  late final Stream<List<LikedItem>> _favs =
      Db.likesForStation(widget.station.id);

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(child: _Header(station: widget.station)),
        SliverToBoxAdapter(child: _tabs()),
        switch (_tab) {
          _Tab.posts => _streamList<Post>(
              _posts,
              empty: 'Esta emisora aún no publica posts.',
              item: (p) => PostCard(post: p, station: widget.station),
            ),
          _Tab.moments => _streamList<AudioMoment>(
              _moments,
              empty: 'Aún no hay audio moments.',
              item: (m) => MomentCard(moment: m, station: widget.station),
            ),
          _Tab.favs => _streamList<LikedItem>(
              _favs,
              empty: 'Toca ♥ en un post o audio moment para guardarlo aquí.',
              item: (l) => l.type == LikeType.post
                  ? PostCard(post: l.toPost(), station: widget.station)
                  : MomentCard(moment: l.toMoment(), station: widget.station),
            ),
        },
        const SliverToBoxAdapter(
          child: SizedBox(height: AppSpacing.spacing2xl24),
        ),
      ],
    );
  }

  Widget _tabs() {
    Widget chip(_Tab t, String label) => Expanded(
          child: TuneInChip(
            label: label,
            selected: _tab == t,
            tone: ChipTone.secondary,
            outlinedWhenInactive: true,
            onTap: () => setState(() => _tab = t),
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppPadding.paddingM12,
        AppPadding.paddingL16,
        AppPadding.paddingM12,
        AppPadding.paddingS8,
      ),
      child: Row(
        children: [
          chip(_Tab.posts, 'Post'),
          const SizedBox(width: AppGap.gapS8),
          chip(_Tab.moments, 'Audio Moments'),
          const SizedBox(width: AppGap.gapS8),
          chip(_Tab.favs, 'Tus Favs'),
        ],
      ),
    );
  }

  Widget _streamList<T>(
    Stream<List<T>> stream, {
    required String empty,
    required Widget Function(T) item,
  }) {
    return StreamBuilder<List<T>>(
      stream: stream,
      builder: (context, snap) {
        if (snap.hasError) {
          return SliverToBoxAdapter(
            child: EmptyState(
              icon: Icons.cloud_off,
              title: 'No se pudo cargar',
              message: '${snap.error}',
            ),
          );
        }
        if (!snap.hasData) {
          return const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(AppPadding.padding3xl32),
              child: Loading(color: SocialTokens.accent),
            ),
          );
        }
        final list = snap.data!;
        if (list.isEmpty) {
          return SliverToBoxAdapter(
            child: EmptyState(icon: Icons.forum_outlined, title: empty),
          );
        }
        return SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: AppPadding.paddingL16),
          sliver: SliverList.separated(
            itemCount: list.length,
            separatorBuilder: (_, _) => const SizedBox(height: AppGap.gapL16),
            itemBuilder: (context, i) => item(list[i]),
          ),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.station});
  final Station station;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(
            AppPadding.paddingL16,
            AppPadding.paddingS8,
            AppPadding.paddingL16,
            AppPadding.padding2xl24,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CoverImage(
                url: station.imageUrl,
                size: 60,
                radius: AppRadius.radiusFull,
              ),
              const SizedBox(width: AppGap.gapL16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      station.name,
                      style: AppTypography.h1.copyWith(
                        color: AppSemanticColors.colorTextMain,
                      ),
                    ),
                    const SizedBox(height: AppGap.gapS8),
                    Text(
                      station.description.isEmpty
                          ? station.subtitle
                          : station.description,
                      style: AppTypography.body1.copyWith(
                        color: AppSemanticColors.colorTextBody,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const Divider(color: SocialTokens.divider),
      ],
    );
  }
}
