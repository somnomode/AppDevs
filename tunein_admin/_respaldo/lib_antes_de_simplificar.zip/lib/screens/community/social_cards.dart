import 'package:flutter/material.dart';

import '../../models/social.dart';
import '../../models/station.dart';
import '../../services/db.dart';
import '../../services/player_controller.dart';
import '../../services/store.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/common.dart';
import '../../widgets/tunein_alert.dart';
import 'comments_screen.dart';

/// Corazón teal para posts / audio moments (guarda en "Tus Favs").
class LikeButton extends StatelessWidget {
  const LikeButton({super.key, required this.item});
  final LikedItem item;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Set<String>>(
      valueListenable: Store.likedIds,
      builder: (context, liked, _) {
        final isLiked = liked.contains(item.itemId);
        return IconButton(
          visualDensity: VisualDensity.compact,
          tooltip: isLiked ? 'Quitar de Tus Favs' : 'Guardar en Tus Favs',
          color: isLiked ? SocialTokens.accent : AppSemanticColors.colorTextMain,
          icon: Icon(isLiked ? Icons.favorite : Icons.favorite_border),
          onPressed: () async {
            try {
              await Db.setLike(item, !isLiked);
            } catch (_) {
              if (context.mounted) {
                showTuneInAlert(context, 'No se pudo guardar.',
                    kind: AlertKind.error);
              }
            }
          },
        );
      },
    );
  }
}

/// Botón pequeño teal ("Comentar", "Enviar").
class TealPillButton extends StatelessWidget {
  const TealPillButton({super.key, required this.label, required this.onTap});
  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: onTap == null ? AppColors.neutral300 : SocialTokens.accent,
      shape: const StadiumBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppPadding.paddingM12,
            vertical: AppPadding.paddingXs4,
          ),
          child: Text(
            label,
            style: AppTypography.btn.copyWith(
              color: AppSemanticColors.colorTextMain,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}

/// Tarjeta de post (Figma: "soc2").
class PostCard extends StatelessWidget {
  const PostCard({
    super.key,
    required this.post,
    required this.station,
    this.showComment = true,
  });

  final Post post;
  final Station station;
  final bool showComment;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppPadding.paddingL16),
      decoration: BoxDecoration(
        color: SocialTokens.cardBg,
        borderRadius: BorderRadius.circular(SocialTokens.cardRadius),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CoverImage(
            url: post.imageUrl,
            size: SocialTokens.coverSize,
            radius: AppRadius.radiusS,
            icon: Icons.image_outlined,
          ),
          const SizedBox(width: AppGap.gapL16),
          Expanded(
            child: SizedBox(
              height: SocialTokens.coverSize,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(top: AppPadding.paddingS8),
                          child: Text(
                            post.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTypography.body1.copyWith(
                              color: AppSemanticColors.colorTextMain,
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                      LikeButton(item: LikedItem.fromPost(post)),
                    ],
                  ),
                  Text(
                    post.summary,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.body1.copyWith(
                      color: AppSemanticColors.colorTextBody,
                    ),
                  ),
                  const Spacer(),
                  if (showComment)
                    Align(
                      alignment: Alignment.bottomRight,
                      child: TealPillButton(
                        label: post.commentCount > 0
                            ? 'Comentar · ${post.commentCount}'
                            : 'Comentar',
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) =>
                                CommentsScreen(post: post, station: station),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Tarjeta de audio moment (Figma: "soc3") con progreso teal.
class MomentCard extends StatelessWidget {
  const MomentCard({super.key, required this.moment, required this.station});

  final AudioMoment moment;
  final Station station;

  @override
  Widget build(BuildContext context) {
    final player = PlayerController.instance;
    return ListenableBuilder(
      listenable: player,
      builder: (context, _) {
        final current = player.isCurrent(moment.id);
        final playing = current && player.isPlaying;
        return Container(
          padding: const EdgeInsets.all(AppPadding.paddingL16),
          decoration: BoxDecoration(
            color: SocialTokens.cardBg,
            borderRadius: BorderRadius.circular(SocialTokens.cardRadius),
          ),
          child: Row(
            children: [
              Semantics(
                button: true,
                label: playing ? 'Pausar' : 'Reproducir',
                child: GestureDetector(
                  onTap: () async {
                    await player.playMoment(moment, station);
                    if (player.error != null && context.mounted) {
                      showTuneInAlert(context, player.error!,
                          kind: AlertKind.error);
                    }
                  },
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CoverImage(
                        url: moment.imageUrl.isNotEmpty
                            ? moment.imageUrl
                            : station.imageUrl,
                        size: 60,
                        radius: AppRadius.radiusS,
                      ),
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: AppColors.neutral900.withValues(alpha: 0.7),
                          shape: BoxShape.circle,
                        ),
                        child: current && player.isLoading
                            ? const Padding(
                                padding: EdgeInsets.all(8),
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: SocialTokens.accent,
                                ),
                              )
                            : Icon(
                                playing ? Icons.pause : Icons.play_arrow,
                                size: 20,
                                color: AppSemanticColors.colorTextMain,
                              ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: AppGap.gapL16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            moment.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: AppTypography.body1.copyWith(
                              color: AppSemanticColors.colorTextMain,
                            ),
                          ),
                        ),
                        LikeButton(item: LikedItem.fromMoment(moment)),
                      ],
                    ),
                    _MomentProgress(moment: moment, active: current),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _MomentProgress extends StatelessWidget {
  const _MomentProgress({required this.moment, required this.active});
  final AudioMoment moment;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final style = AppTypography.data2.copyWith(
      color: AppSemanticColors.colorTextMain,
    );
    if (!active) {
      return _bar(0, style, Duration.zero, moment.duration);
    }
    final player = PlayerController.instance;
    return StreamBuilder<Duration>(
      stream: player.positionStream,
      initialData: player.position,
      builder: (context, snap) {
        final total = player.duration ?? moment.duration;
        final pos = snap.data ?? Duration.zero;
        final v = (total == null || total.inMilliseconds == 0)
            ? 0.0
            : (pos.inMilliseconds / total.inMilliseconds).clamp(0.0, 1.0);
        return _bar(v, style, pos, total);
      },
    );
  }

  Widget _bar(double v, TextStyle style, Duration pos, Duration? total) {
    return Column(
      children: [
        const SizedBox(height: AppGap.gapXs4),
        ClipRRect(
          borderRadius: BorderRadius.circular(AppRadius.radiusFull),
          child: LinearProgressIndicator(
            value: v,
            minHeight: 4,
            color: SocialTokens.trackActive,
            backgroundColor: SocialTokens.trackInactive,
          ),
        ),
        const SizedBox(height: AppGap.gapXs4),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(formatDuration(pos), style: style),
            Text(formatDuration(total), style: style),
          ],
        ),
      ],
    );
  }
}
