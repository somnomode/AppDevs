import 'package:flutter/material.dart';

import '../../models/social.dart';
import '../../models/station.dart';
import '../../services/current_user.dart';
import '../../services/db.dart';
import '../../services/store.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/common.dart';
import '../../widgets/tunein_alert.dart';
import 'social_cards.dart';

/// Comentarios de un post (Figma: "soc 4").
class CommentsScreen extends StatefulWidget {
  const CommentsScreen({super.key, required this.post, required this.station});

  final Post post;
  final Station station;

  @override
  State<CommentsScreen> createState() => _CommentsScreenState();
}

class _CommentsScreenState extends State<CommentsScreen> {
  final _text = TextEditingController();
  late final Stream<List<Comment>> _comments =
      Db.comments(widget.station.id, widget.post.id);
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _text.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _text.text.trim();
    if (text.isEmpty) return;
    setState(() => _sending = true);
    try {
      await Db.addComment(
        stationId: widget.station.id,
        postId: widget.post.id,
        text: text,
        username: Store.me.value?.username ?? CurrentUser.username,
      );
      _text.clear();
      if (mounted) FocusScope.of(context).unfocus();
    } catch (_) {
      if (mounted) {
        showTuneInAlert(context, 'No se pudo enviar el comentario.',
            kind: AlertKind.error);
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SocialTokens.bg,
      appBar: AppBar(
        backgroundColor: SocialTokens.bg,
        title: Text(
          'Comentarios',
          style: AppTypography.h3.copyWith(
            color: AppSemanticColors.colorTextMain,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(
                  horizontal: AppPadding.paddingL16,
                ),
                decoration: BoxDecoration(
                  color: SocialTokens.cardBg,
                  borderRadius:
                      BorderRadius.circular(SocialTokens.cardRadius),
                ),
                child: StreamBuilder<List<Comment>>(
                  stream: _comments,
                  builder: (context, snap) {
                    final list = snap.data ?? const <Comment>[];
                    return ListView(
                      children: [
                        PostCard(
                          post: widget.post,
                          station: widget.station,
                          showComment: false,
                        ),
                        if (!snap.hasData)
                          const Padding(
                            padding: EdgeInsets.all(AppPadding.paddingXl20),
                            child: Loading(color: SocialTokens.accent),
                          )
                        else if (list.isEmpty)
                          Padding(
                            padding:
                                const EdgeInsets.all(AppPadding.paddingXl20),
                            child: Text(
                              'Sé el primero en comentar.',
                              style: AppTypography.body1.copyWith(
                                color: AppSemanticColors.colorTextMuted,
                              ),
                            ),
                          ),
                        for (final c in list) ...[
                          _CommentTile(comment: c),
                          const Divider(color: SocialTokens.divider),
                        ],
                      ],
                    );
                  },
                ),
              ),
            ),
            _composer(),
          ],
        ),
      ),
    );
  }

  Widget _composer() {
    return Container(
      margin: const EdgeInsets.all(AppPadding.paddingL16),
      padding: const EdgeInsets.fromLTRB(
        AppPadding.paddingXl20,
        AppPadding.paddingS8,
        AppPadding.paddingM12,
        AppPadding.paddingM12,
      ),
      decoration: BoxDecoration(
        color: SocialTokens.inputBg,
        borderRadius: BorderRadius.circular(AppRadius.radiusM),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          TextField(
            controller: _text,
            minLines: 2,
            maxLines: 4,
            textCapitalization: TextCapitalization.sentences,
            style: AppTypography.body1.copyWith(
              color: AppSemanticColors.colorTextMain,
            ),
            cursorColor: SocialTokens.accent,
            decoration: InputDecoration(
              hintText: 'Escribir aquí',
              hintStyle: AppTypography.data2.copyWith(
                color: AppColors.neutral100,
              ),
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: EdgeInsets.zero,
            ),
          ),
          TealPillButton(
            label: _sending ? 'Enviando…' : 'Enviar',
            onTap: _text.text.trim().isEmpty || _sending ? null : _send,
          ),
        ],
      ),
    );
  }
}

class _CommentTile extends StatelessWidget {
  const _CommentTile({required this.comment});
  final Comment comment;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppPadding.paddingL16,
        vertical: AppPadding.paddingM12,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.account_circle_outlined,
            size: 28,
            color: AppColors.neutral100,
          ),
          const SizedBox(width: AppGap.gapM12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  comment.username,
                  style: AppTypography.body1.copyWith(
                    color: AppSemanticColors.colorTextMain,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  comment.text,
                  style: AppTypography.body2.copyWith(
                    color: AppSemanticColors.colorTextBody,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
