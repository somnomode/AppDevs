import 'package:flutter/material.dart';

import '../../services/db.dart';
import '../../services/player_controller.dart';
import '../../services/store.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/app_header.dart';
import '../../widgets/common.dart';
import '../player/player_screen.dart';

/// Librería (Figma: "librerias") — emisoras guardadas con ♥.
class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const AppHeader(),
        const SectionTitle('Librería'),
        Expanded(
          child: ListenableBuilder(
            listenable: Listenable.merge([
              Store.stations,
              Store.favoriteIds,
              PlayerController.instance,
            ]),
            builder: (context, _) {
              if (Store.stations.value == null) return const Loading();
              final favs = Store.favoriteStations;
              if (favs.isEmpty) {
                return const EmptyState(
                  icon: Icons.favorite_border,
                  title: 'Tu librería está vacía',
                  message: 'Toca ♥ en el reproductor para guardar emisoras.',
                );
              }
              return ListView.separated(
                itemCount: favs.length,
                separatorBuilder: (_, _) => const Divider(
                  indent: AppPadding.paddingL16,
                  endIndent: AppPadding.paddingL16,
                ),
                itemBuilder: (context, i) {
                  final s = favs[i];
                  return StationListTile(
                    title: s.name,
                    subtitle: s.subtitle,
                    imageUrl: s.imageUrl,
                    highlighted: PlayerController.instance.isCurrent(s.id),
                    onTap: () => openStation(context, s, queue: favs),
                    trailing: IconButton(
                      tooltip: 'Quitar de la librería',
                      color: ListItemTokens.favorite,
                      icon: const Icon(Icons.favorite),
                      onPressed: () => Db.setFavorite(s.id, false),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
