import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../models/station.dart';
import '../../services/app_nav.dart';
import '../../services/store.dart';
import '../../theme/component_tokens.dart';
import '../../theme/theme.dart';
import '../../widgets/common.dart';
import '../player/player_screen.dart';
import 'map_style.dart';

/// Mapa (Figma: "mapa") — emisoras según su ubicación, con Google Maps.
///
/// IMPORTANTE: el mapa de Google solo se crea cuando la pestaña Map está
/// abierta. Si se crea escondido detrás de otra pestaña, en Android puede
/// dejar la pantalla en negro.
class MapScreen extends StatelessWidget {
  const MapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: AppNav.tab,
      builder: (context, tab, _) => tab == AppNav.map
          ? const _StationsMap()
          : const ColoredBox(color: AppColors.neutral700),
    );
  }
}

class _StationsMap extends StatefulWidget {
  const _StationsMap();

  @override
  State<_StationsMap> createState() => _StationsMapState();
}

class _StationsMapState extends State<_StationsMap> {
  GoogleMapController? _controller;
  Station? _selected;

  /// Vista inicial: Sudamérica completa.
  static const _start = CameraPosition(target: LatLng(-30, -64), zoom: 3.2);

  /// Tono del pin (0–360). 16 ≈ primary-400 #FF6B35.
  static const double _pinHue = 16;

  @override
  void initState() {
    super.initState();
    AppNav.mapFocus.addListener(_focus);
  }

  @override
  void dispose() {
    AppNav.mapFocus.removeListener(_focus);
    super.dispose();
  }

  /// "Encontrar en el mapa" desde el reproductor: centra la emisora.
  Future<void> _focus() async {
    final s = AppNav.mapFocus.value;
    if (s == null || !s.hasLocation || !mounted) return;
    setState(() => _selected = s);
    await _controller?.animateCamera(
      CameraUpdate.newLatLngZoom(LatLng(s.lat!, s.lng!), 10),
    );
    AppNav.mapFocus.value = null; // ya se usó
  }

  Set<Marker> _markers(List<Station> located) => {
        for (final s in located)
          Marker(
            markerId: MarkerId(s.id),
            position: LatLng(s.lat!, s.lng!),
            icon: BitmapDescriptor.defaultMarkerWithHue(_pinHue),
            infoWindow: InfoWindow(title: s.name, snippet: s.frequency),
            onTap: () => setState(() => _selected = s),
          ),
      };

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<List<Station>?>(
      valueListenable: Store.stations,
      builder: (context, stations, _) {
        final located = (stations ?? const <Station>[])
            .where((s) => s.hasLocation)
            .toList();
        return Stack(
          children: [
            GoogleMap(
              initialCameraPosition: _start,
              style: tuneInMapStyle, // mapa oscuro con colores del sistema
              markers: _markers(located),
              myLocationEnabled: false,
              myLocationButtonEnabled: false,
              mapToolbarEnabled: false,
              zoomControlsEnabled: false,
              compassEnabled: false,
              onMapCreated: (c) {
                _controller = c;
                _focus(); // por si venimos desde "Encontrar en el mapa"
              },
              onTap: (_) => setState(() => _selected = null),
            ),
            if (_selected != null)
              Positioned(
                left: AppPadding.paddingL16,
                right: AppPadding.paddingL16,
                bottom: AppPadding.padding3xl32,
                child: _StationCard(
                  station: _selected!,
                  onPlay: () =>
                      openStation(context, _selected!, queue: located),
                ),
              ),
          ],
        );
      },
    );
  }
}

/// Tarjeta que aparece al tocar un pin.
class _StationCard extends StatelessWidget {
  const _StationCard({required this.station, required this.onPlay});
  final Station station;
  final VoidCallback onPlay;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: ListItemTokens.bg,
      borderRadius: BorderRadius.circular(AppRadius.radiusS),
      clipBehavior: Clip.antiAlias,
      child: StationListTile(
        title: station.name,
        subtitle: '${station.frequency} · ${station.location}',
        imageUrl: station.imageUrl,
        onTap: onPlay,
        trailing: IconButton(
          tooltip: 'Escuchar',
          iconSize: 32,
          onPressed: onPlay,
          icon: const Icon(Icons.play_arrow_outlined),
        ),
      ),
    );
  }
}
