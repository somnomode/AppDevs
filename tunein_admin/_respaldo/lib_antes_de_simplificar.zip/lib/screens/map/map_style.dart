// Estilo del mapa de Google en modo oscuro, usando los colores de TuneIn.
// Formato: JSON de estilos de Google Maps
// (https://developers.google.com/maps/documentation/android-sdk/styling).
//
// Colores (de theme.dart):
//   tierra      neutral-700  #0D1028
//   agua        neutral-900  #03040D
//   calles      neutral-500  #1F2249
//   bordes      neutral-300  #4E5182
//   textos      neutral-100  #ABADCA
//   capitales   primary-300  #FA916A

const String tuneInMapStyle = '''
[
  {"elementType": "geometry", "stylers": [{"color": "#0D1028"}]},
  {"elementType": "labels.icon", "stylers": [{"visibility": "off"}]},
  {"elementType": "labels.text.fill", "stylers": [{"color": "#ABADCA"}]},
  {"elementType": "labels.text.stroke", "stylers": [{"color": "#03040D"}]},
  {"featureType": "administrative", "elementType": "geometry.stroke", "stylers": [{"color": "#4E5182"}]},
  {"featureType": "administrative.country", "elementType": "labels.text.fill", "stylers": [{"color": "#EFF0F6"}]},
  {"featureType": "administrative.locality", "elementType": "labels.text.fill", "stylers": [{"color": "#FA916A"}]},
  {"featureType": "poi", "stylers": [{"visibility": "off"}]},
  {"featureType": "transit", "stylers": [{"visibility": "off"}]},
  {"featureType": "road", "elementType": "geometry", "stylers": [{"color": "#1F2249"}]},
  {"featureType": "road", "elementType": "labels", "stylers": [{"visibility": "off"}]},
  {"featureType": "landscape.natural", "elementType": "geometry", "stylers": [{"color": "#151839"}]},
  {"featureType": "water", "elementType": "geometry", "stylers": [{"color": "#03040D"}]},
  {"featureType": "water", "elementType": "labels.text.fill", "stylers": [{"color": "#4E5182"}]}
]
''';
