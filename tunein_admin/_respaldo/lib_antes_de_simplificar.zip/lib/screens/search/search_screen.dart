import 'package:flutter/material.dart';

import '../../models/station.dart';
import '../../services/app_nav.dart';
import '../../services/store.dart';
import '../../theme/theme.dart';
import '../../widgets/common.dart';
import '../player/player_screen.dart';

/// Búsqueda (Figma: " en busqueda" / "Recien en busqueda").
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _query = TextEditingController();
  final _focus = FocusNode();

  @override
  void dispose() {
    _query.dispose();
    _focus.dispose();
    super.dispose();
  }

  static String _norm(String s) => s
      .toLowerCase()
      .replaceAll(RegExp('[áà]'), 'a')
      .replaceAll(RegExp('[éè]'), 'e')
      .replaceAll(RegExp('[íì]'), 'i')
      .replaceAll(RegExp('[óò]'), 'o')
      .replaceAll(RegExp('[úùü]'), 'u')
      .replaceAll('ñ', 'n');

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _searchBar(),
        Expanded(
          child: ListenableBuilder(
            listenable: Listenable.merge([Store.stations, Store.recentIds, _query]),
            builder: (context, _) {
              final all = Store.stations.value;
              if (all == null) return const Loading();
              final q = _norm(_query.text.trim());
              return q.isEmpty ? _idle(all) : _results(all, q);
            },
          ),
        ),
      ],
    );
  }

  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppPadding.paddingS8,
        AppPadding.paddingS8,
        AppPadding.paddingL16,
        AppPadding.paddingS8,
      ),
      child: Row(
        children: [
          IconButton(
            tooltip: 'Volver',
            icon: const Icon(Icons.arrow_back_ios_new, size: 20),
            onPressed: () {
              _query.clear();
              _focus.unfocus();
              AppNav.tab.value = AppNav.home;
            },
          ),
          Expanded(
            child: SizedBox(
              height: 40,
              child: TextField(
                controller: _query,
                focusNode: _focus,
                textInputAction: TextInputAction.search,
                style: AppTypography.body1.copyWith(
                  color: AppColors.neutral900,
                ),
                cursorColor: AppColors.neutral900,
                decoration: InputDecoration(
                  hintText: 'Busca emisoras, géneros o ciudades',
                  hintStyle: AppTypography.body1.copyWith(
                    color: AppColors.neutral300,
                  ),
                  filled: true,
                  fillColor: AppColors.neutral50,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: AppPadding.paddingL16,
                  ),
                  suffixIcon: _query.text.isEmpty
                      ? const Icon(Icons.search, color: AppColors.neutral900)
                      : IconButton(
                          tooltip: 'Borrar',
                          icon: const Icon(Icons.close,
                              color: AppColors.neutral900),
                          onPressed: _query.clear,
                        ),
                  enabledBorder: const OutlineInputBorder(
                    borderRadius:
                        BorderRadius.all(Radius.circular(AppRadius.radiusFull)),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderRadius:
                        BorderRadius.all(Radius.circular(AppRadius.radiusFull)),
                    borderSide: BorderSide(
                      color: AppSemanticColors.colorBrandPrimary,
                      width: 2,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _idle(List<Station> all) {
    final recents = Store.recentStations;
    return ListView(
      children: [
        if (recents.isNotEmpty) ...[
          _label('Recientes'),
          SizedBox(
            height: 100,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(
                horizontal: AppPadding.paddingL16,
              ),
              itemCount: recents.length,
              separatorBuilder: (_, _) => const SizedBox(width: AppGap.gapS8),
              itemBuilder: (context, i) {
                final s = recents[i];
                return SizedBox(
                  width: 56,
                  child: InkWell(
                    onTap: () => openStation(context, s, queue: recents),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CoverImage(url: s.imageUrl, size: 56),
                        const SizedBox(height: AppGap.gapXs4),
                        Text(
                          s.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.caption.copyWith(
                            color: AppSemanticColors.colorTextMain,
                          ),
                        ),
                        Text(
                          s.genre,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.caption.copyWith(
                            color: AppSemanticColors.colorTextMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
        _label('Recomendaciones'),
        ..._tiles(all),
      ],
    );
  }

  Widget _results(List<Station> all, String q) {
    final found = all.where((s) {
      final hay = _norm('${s.name} ${s.genre} ${s.location} ${s.frequency}');
      return hay.contains(q);
    }).toList();
    if (found.isEmpty) {
      return EmptyState(
        icon: Icons.search_off,
        title: 'Sin resultados para "${_query.text.trim()}"',
      );
    }
    return ListView(children: _tiles(found));
  }

  List<Widget> _tiles(List<Station> list) => [
        for (final s in list)
          Padding(
            padding: const EdgeInsets.only(bottom: AppGap.gapS8),
            child: StationListTile(
              filled: true,
              title: s.name,
              subtitle: s.subtitle,
              imageUrl: s.imageUrl,
              onTap: () {
                _focus.unfocus();
                openStation(context, s, queue: list);
              },
              trailing: const Icon(Icons.play_arrow_outlined),
            ),
          ),
      ];

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(
          AppPadding.paddingL16,
          AppPadding.paddingM12,
          AppPadding.paddingL16,
          AppPadding.paddingS8,
        ),
        child: Text(
          text,
          style: AppTypography.sub2.copyWith(
            color: AppSemanticColors.colorTextMain,
          ),
        ),
      );
}
