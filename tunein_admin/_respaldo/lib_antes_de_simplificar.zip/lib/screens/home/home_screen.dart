import 'package:flutter/material.dart';

import '../../models/station.dart';
import '../../services/store.dart';
import '../../theme/theme.dart';
import '../../widgets/app_header.dart';
import '../../widgets/common.dart';
import '../player/player_screen.dart';
import '../profile/profile_screen.dart';

/// Home (Figma: "menu inicio").
/// Chips de categoría → Recientes (grilla) → una sección por género.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _category = StationCategory.radio;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([Store.stations, Store.recentIds, Store.error]),
      builder: (context, _) {
        final all = Store.stations.value;
        return CustomScrollView(
          slivers: [
            const SliverToBoxAdapter(child: AppHeader()),
            SliverToBoxAdapter(child: _chips()),
            if (Store.error.value != null && all == null)
              SliverFillRemaining(
                hasScrollBody: false,
                child: EmptyState(
                  icon: Icons.cloud_off,
                  title: 'No se pudo conectar con Firestore',
                  message: Store.error.value,
                ),
              )
            else if (all == null)
              const SliverFillRemaining(child: Loading())
            else if (all.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: EmptyState(
                  icon: Icons.radio,
                  title: 'Todavía no hay emisoras',
                  message: 'Carga los datos demo desde tu perfil.',
                  action: FilledButton(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const ProfileScreen(),
                      ),
                    ),
                    child: const Text('IR A PERFIL'),
                  ),
                ),
              )
            else
              ..._sections(all),
            const SliverToBoxAdapter(
              child: SizedBox(height: AppSpacing.spacing2xl24),
            ),
          ],
        );
      },
    );
  }

  Widget _chips() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppPadding.paddingL16,
        vertical: AppPadding.paddingS8,
      ),
      child: Row(
        children: [
          for (final c in StationCategory.all) ...[
            Expanded(
              child: TuneInChip(
                label: StationCategory.label(c),
                selected: c == _category,
                onTap: () => setState(() => _category = c),
              ),
            ),
            if (c != StationCategory.all.last)
              const SizedBox(width: AppGap.gapS8),
          ],
        ],
      ),
    );
  }

  List<Widget> _sections(List<Station> all) {
    final inCategory = all.where((s) => s.category == _category).toList();
    if (inCategory.isEmpty) {
      return [
        SliverFillRemaining(
          hasScrollBody: false,
          child: EmptyState(
            icon: Icons.search_off,
            title: 'Sin contenido en ${StationCategory.label(_category)}',
          ),
        ),
      ];
    }

    // Recientes de esta categoría; si no hay, destacadas.
    var recents = Store.recentStations
        .where((s) => s.category == _category)
        .toList();
    if (recents.isEmpty) recents = inCategory;
    recents = recents.take(6).toList();

    // Agrupar por género manteniendo el orden.
    final byGenre = <String, List<Station>>{};
    for (final s in inCategory) {
      byGenre.putIfAbsent(s.genre, () => []).add(s);
    }

    final slivers = <Widget>[
      const SliverToBoxAdapter(child: SectionTitle('Recientes')),
      SliverPadding(
        padding: const EdgeInsets.symmetric(horizontal: AppPadding.paddingXl20),
        sliver: SliverGrid.count(
          crossAxisCount: 3,
          mainAxisSpacing: AppGap.gapS8,
          crossAxisSpacing: AppGap.gapM12,
          children: [
            for (final s in recents)
              _CoverTile(station: s, queue: inCategory),
          ],
        ),
      ),
    ];

    var i = 0;
    for (final entry in byGenre.entries) {
      slivers
        ..add(SliverToBoxAdapter(child: SectionTitle(entry.key)))
        ..add(
          SliverToBoxAdapter(
            child: i.isEven
                ? _CardRow(stations: entry.value, queue: inCategory)
                : _TwoRowList(stations: entry.value, queue: inCategory),
          ),
        );
      i++;
    }
    return slivers;
  }
}

/// Portada cuadrada (grilla de Recientes).
class _CoverTile extends StatelessWidget {
  const _CoverTile({required this.station, required this.queue});
  final Station station;
  final List<Station> queue;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: station.name,
      child: GestureDetector(
        onTap: () => openStation(context, station, queue: queue),
        child: CoverImage(url: station.imageUrl, radius: AppRadius.radiusXs),
      ),
    );
  }
}

/// Fila horizontal: portada 64 + nombre + género debajo (sección "Musica").
class _CardRow extends StatelessWidget {
  const _CardRow({required this.stations, required this.queue});
  final List<Station> stations;
  final List<Station> queue;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 112,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppPadding.paddingXl20),
        itemCount: stations.length,
        separatorBuilder: (_, _) => const SizedBox(width: AppGap.gapS8),
        itemBuilder: (context, i) {
          final s = stations[i];
          return SizedBox(
            width: 64,
            child: InkWell(
              onTap: () => openStation(context, s, queue: queue),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CoverImage(url: s.imageUrl, size: 64),
                  const SizedBox(height: AppGap.gapXs4),
                  Text(
                    s.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.body2.copyWith(
                      color: AppSemanticColors.colorTextMain,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    s.genre,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.body2.copyWith(
                      color: AppColors.neutral200,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Lista horizontal de 2 filas: portada + nombre a la derecha ("Noticias").
class _TwoRowList extends StatelessWidget {
  const _TwoRowList({required this.stations, required this.queue});
  final List<Station> stations;
  final List<Station> queue;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 64 * 2 + AppGap.gapM12,
      child: GridView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppPadding.paddingXl20),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: AppGap.gapL16,
          crossAxisSpacing: AppGap.gapM12,
          mainAxisExtent: 148,
        ),
        itemCount: stations.length,
        itemBuilder: (context, i) {
          final s = stations[i];
          return InkWell(
            onTap: () => openStation(context, s, queue: queue),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CoverImage(url: s.imageUrl, size: 64),
                const SizedBox(width: AppGap.gapS8),
                Expanded(
                  child: Text(
                    s.name,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.body2.copyWith(
                      color: AppSemanticColors.colorTextMain,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
